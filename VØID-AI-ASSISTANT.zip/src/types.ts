export type ScreenId = 
  | 'home' 
  | 'memory' 
  | 'settings' 
  | 'permissions' 
  | 'apisettings' 
  | 'pccloud'
  | 'phoneaccessibility'
  | 'codestudio'
  | 'androidsource';

export interface GeneratedCodeItem {
  id: string;
  title: string;
  language: string;
  code: string;
  explanation: string;
  fileName: string;
  timestamp: number;
}

export interface ConversationItem {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  model: string;
  voice?: string;
  bytes: number;
  actionTaken?: string;
}

export interface PcCloudState {
  connected: boolean;
  ip: string;
  connectionCode: string;
  clientName: string;
  cursor: { x: number; y: number };
  activeWindow: string;
  latencyMs: number;
  fps: number;
  terminalLogs: string[];
  lastAction: string;
}

export interface PhoneSimulationState {
  accessibilityEnabled: boolean;
  foregroundListening: boolean;
  currentApp: string; // 'Home' | 'Instagram' | 'Chrome' | 'Messages' | 'Settings' | 'Camera' | 'QrScanner'
  recentAction: string;
  inspectedNodesCount: number;
  screenshotUrl: string | null;
  scannedQrCode: string | null;
}

export interface ApiSettingsState {
  apiKey: string;
  model: 'gemini-3.8-flash' | 'gemini-3.1-pro' | 'gemini-2.5-flash';
  voice: 'Charon' | 'Fenrir';
  pitch: number;
  speechRate: number;
  encrypted: boolean;
  alwaysListening: boolean;
}

export type MacroActionType = 
  | 'open_app'
  | 'connect_pc'
  | 'pc_type'
  | 'pc_shortcut'
  | 'set_voice_tone'
  | 'take_screenshot'
  | 'scroll_screen'
  | 'speak_phrase';

export interface MacroAction {
  id: string;
  type: MacroActionType;
  title: string;
  payload: {
    app?: string;
    connect?: boolean;
    text?: string;
    key?: string;
    pitch?: number;
    speechRate?: number;
    voice?: 'Charon' | 'Fenrir';
    direction?: 'up' | 'down';
    message?: string;
  };
}

export interface VoiceMacro {
  id: string;
  triggerPhrase: string; // e.g., "start work", "stealth mode", "gaming mode"
  description: string;
  enabled: boolean;
  actions: MacroAction[];
  executionCount: number;
  lastTriggered?: number;
}
