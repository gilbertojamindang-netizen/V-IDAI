import { useEffect, useRef, useState, useCallback } from 'react';
import { VoidaiNative } from 'voidai-native';
import type { PluginListenerHandle } from '@capacitor/core';

/**
 * React hook wiring VOID.AI's UI to the native plugin:
 * offline speech-to-text, offline TTS, the accessibility automation bridge,
 * and the local on-device LLM.
 *
 * Usage inside a component, e.g. HomeScreenView.tsx:
 *
 *   const { listen, speak, ask, isListening } = useVoidNative();
 *   const onMicPress = async () => {
 *     const { text } = await listen();
 *     const { reply } = await ask(text);
 *     await speak(reply);
 *   };
 */
export function useVoidNative() {
  const [isListening, setIsListening] = useState(false);
  const [partialText, setPartialText] = useState('');
  const [accessibilityEnabled, setAccessibilityEnabled] = useState(false);
  const listenersRef = useRef<PluginListenerHandle[]>([]);

  useEffect(() => {
    let mounted = true;

    const setup = async () => {
      const l1 = await VoidaiNative.addListener('listeningState', (data: any) => {
        setIsListening(data.state === 'speaking' || data.state === 'ready');
      });
      const l2 = await VoidaiNative.addListener('partialResult', (data: any) => {
        if (mounted) setPartialText(data.text);
      });
      listenersRef.current = [l1, l2];

      const { enabled } = await VoidaiNative.isAccessibilityServiceEnabled();
      if (mounted) setAccessibilityEnabled(enabled);
    };
    setup();

    return () => {
      mounted = false;
      listenersRef.current.forEach((h) => h.remove());
    };
  }, []);

  const listen = useCallback(async () => {
    setPartialText('');
    return VoidaiNative.startListening();
  }, []);

  const stopListening = useCallback(() => VoidaiNative.stopListening(), []);

  const speak = useCallback(async (text: string) => {
    return VoidaiNative.speak({ text });
  }, []);

  const ask = useCallback(async (prompt: string) => {
    const { loaded } = await VoidaiNative.isLlmLoaded();
    if (!loaded) {
      throw new Error('Local LLM not loaded yet — call loadLlmModel() first, see ANDROID_BUILD.md');
    }
    return VoidaiNative.askLlm({ prompt });
  }, []);

  const requestAccessibility = useCallback(async () => {
    await VoidaiNative.openAccessibilitySettings();
  }, []);

  const refreshAccessibilityStatus = useCallback(async () => {
    const { enabled } = await VoidaiNative.isAccessibilityServiceEnabled();
    setAccessibilityEnabled(enabled);
    return enabled;
  }, []);

  const openApp = useCallback((packageName: string) => VoidaiNative.openApp({ packageName }), []);
  const tapByLabel = useCallback((label: string) => VoidaiNative.tapByLabel({ label }), []);
  const readScreen = useCallback(() => VoidaiNative.readScreen(), []);

  return {
    isListening,
    partialText,
    accessibilityEnabled,
    listen,
    stopListening,
    speak,
    ask,
    requestAccessibility,
    refreshAccessibilityStatus,
    openApp,
    tapByLabel,
    readScreen,
  };
}
