import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ScreenId, ConversationItem, PcCloudState, PhoneSimulationState, ApiSettingsState, VoiceMacro, GeneratedCodeItem } from './types';
import { NavigationDrawer } from './components/NavigationDrawer';
import { HomeScreenView } from './components/screens/HomeScreenView';
import { PcCloudScreenView } from './components/screens/PcCloudScreenView';
import { PhoneAccessibilityScreenView } from './components/screens/PhoneAccessibilityScreenView';
import { MemoryScreenView } from './components/screens/MemoryScreenView';
import { ApiSettingsScreenView } from './components/screens/ApiSettingsScreenView';
import { PermissionsScreenView } from './components/screens/PermissionsScreenView';
import { SettingsScreenView } from './components/screens/SettingsScreenView';
import { AndroidSourceScreenView } from './components/screens/AndroidSourceScreenView';
import { AiCodeStudioScreenView } from './components/screens/AiCodeStudioScreenView';
import { ChangeAvatarModal } from './components/ChangeAvatarModal';

export default function App() {
  // Navigation State
  const [activeScreen, setActiveScreen] = useState<ScreenId>('home');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Avatar Image State (defaults to new hooded tactical cyborg, customizable or uploadable)
  const [avatarImageUrl, setAvatarImageUrl] = useState<string>(() => {
    try {
      return localStorage.getItem('void_avatar_image') || '/src/assets/images/void_hooded_cyborg_1793161662943.jpg';
    } catch {
      return '/src/assets/images/void_hooded_cyborg_1793161662943.jpg';
    }
  });
  const [isChangeAvatarOpen, setIsChangeAvatarOpen] = useState(false);

  const handleSelectAvatar = (url: string) => {
    setAvatarImageUrl(url);
    try {
      localStorage.setItem('void_avatar_image', url);
    } catch (e) {
      console.warn('Failed to save avatar image to localStorage:', e);
    }
  };

  // Voice Macros State
  const [macros, setMacros] = useState<VoiceMacro[]>(() => {
    try {
      const saved = localStorage.getItem('void_macros');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'macro_work',
        triggerPhrase: 'start work',
        description: 'Opens Chrome, connects to PC Cloud workstation, types dev command, and confirms.',
        enabled: true,
        executionCount: 3,
        actions: [
          { id: 'a1', type: 'open_app', title: 'Launch App: Chrome', payload: { app: 'Chrome' } },
          { id: 'a2', type: 'connect_pc', title: 'Connect to PC Cloud', payload: { connect: true } },
          { id: 'a3', type: 'pc_type', title: 'Type on PC: "npm run dev"', payload: { text: 'npm run dev' } },
          { id: 'a4', type: 'speak_phrase', title: 'Speak: "Workstation linked. Development environment active."', payload: { message: 'Workstation linked. Development environment active.' } },
        ]
      },
      {
        id: 'macro_stealth',
        triggerPhrase: 'stealth mode',
        description: 'Sets deep baritone pitch, opens terminal, captures screenshot, and confirms.',
        enabled: true,
        executionCount: 1,
        actions: [
          { id: 'b1', type: 'set_voice_tone', title: 'Set Voice Pitch to 0.60x', payload: { pitch: 0.60 } },
          { id: 'b2', type: 'open_app', title: 'Launch App: Terminal', payload: { app: 'Terminal' } },
          { id: 'b3', type: 'take_screenshot', title: 'Capture Display Screenshot', payload: {} },
          { id: 'b4', type: 'speak_phrase', title: 'Speak: "Stealth protocol active. Tactical feeds secured."', payload: { message: 'Stealth protocol active. Tactical feeds secured.' } }
        ]
      }
    ];
  });
  const [executingMacroId, setExecutingMacroId] = useState<string | null>(null);

  const saveMacros = (newMacros: VoiceMacro[]) => {
    setMacros(newMacros);
    try {
      localStorage.setItem('void_macros', JSON.stringify(newMacros));
    } catch {}
  };

  const handleAddMacro = (macro: VoiceMacro) => {
    saveMacros([macro, ...macros]);
  };

  const handleUpdateMacro = (updated: VoiceMacro) => {
    saveMacros(macros.map(m => m.id === updated.id ? updated : m));
  };

  const handleDeleteMacro = (id: string) => {
    saveMacros(macros.filter(m => m.id !== id));
  };

  // AI Coding Studio State
  const [codeHistory, setCodeHistory] = useState<GeneratedCodeItem[]>(() => {
    try {
      const saved = localStorage.getItem('void_code_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);

  const handleGenerateCode = async (prompt: string, language: string): Promise<GeneratedCodeItem | null> => {
    setIsGeneratingCode(true);
    try {
      const res = await fetch('/api/gemini/generate-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          language,
          customApiKey: apiSettings.apiKey
        })
      });
      const data = await res.json();
      const newItem: GeneratedCodeItem = {
        id: `code_${Date.now()}`,
        title: prompt,
        language: data.language || language,
        code: data.code || '# Generated code placeholder',
        explanation: data.explanation || 'Code synthesized by VOID Developer Subsystem.',
        fileName: data.fileName || `void_script.${language === 'python' ? 'py' : 'sh'}`,
        timestamp: Date.now()
      };

      const updated = [newItem, ...codeHistory];
      setCodeHistory(updated);
      try {
        localStorage.setItem('void_code_history', JSON.stringify(updated.slice(0, 20)));
      } catch {}

      return newItem;
    } catch (err) {
      console.error('Code Gen Error:', err);
      return null;
    } finally {
      setIsGeneratingCode(false);
    }
  };

  const handleSendCodeToPc = (code: string, fileName: string) => {
    setPcState(prev => ({
      ...prev,
      terminalLogs: [
        ...prev.terminalLogs,
        `[DEV ENGINE] Injected ${fileName} (${code.split('\n').length} lines) into workstation editor.`
      ],
      lastAction: `Injected ${fileName} on PC`
    }));
    speakDeepVoice(`Code injected into workstation editor for ${fileName}.`);
  };

  const handleExecuteOnPc = (command: string) => {
    setPcState(prev => ({
      ...prev,
      terminalLogs: [
        ...prev.terminalLogs,
        `$ ${command}`,
        `[EXEC] Process spawned. Returncode: 0`
      ],
      lastAction: `Executed: ${command}`
    }));
    speakDeepVoice(`Executing command on PC workstation: ${command}.`);
  };

  // Voice Assistant State
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [assistantReply, setAssistantReply] = useState('');

  // Memory (Room Database State - 30 MB simulated quota)
  const [conversations, setConversations] = useState<ConversationItem[]>(() => {
    return [
      {
        id: 'mem_01',
        role: 'user',
        text: 'VOID, initialize system diagnostics and check PC Cloud link.',
        timestamp: Date.now() - 1000 * 60 * 12,
        model: 'Gemini-3.8-Live',
        voice: 'Charon',
        bytes: 148,
        actionTaken: 'Status verified. Standby.'
      },
      {
        id: 'mem_02',
        role: 'model',
        text: 'All tactical subroutines verified. Accessibility Service online, PC Cloud socket ready. I am standing by.',
        timestamp: Date.now() - 1000 * 60 * 11,
        model: 'Gemini-3.8-Live',
        voice: 'Charon',
        bytes: 210,
        actionTaken: 'Diagnostics Complete'
      }
    ];
  });

  // Calculate total Room storage bytes
  const totalBytesUsed = conversations.reduce((acc, c) => acc + (c.bytes || c.text.length * 2), 0) + 1024 * 48; // base overhead

  // PC Cloud State
  const [pcState, setPcState] = useState<PcCloudState>({
    connected: true,
    ip: '192.168.1.188:8080',
    connectionCode: 'VOID-7782',
    clientName: 'VOID_WORKSTATION_PRO',
    cursor: { x: 260, y: 180 },
    activeWindow: 'Terminal - bash',
    latencyMs: 12,
    fps: 60,
    terminalLogs: [
      'QuickTrip Daemon listening on port 8080',
      'Remote input relay initialized',
      'Virtual mouse driver calibrated: [0,0]->[1920,1080]'
    ],
    lastAction: 'Standing by'
  });

  // Phone & Accessibility State
  const [phoneState, setPhoneState] = useState<PhoneSimulationState>({
    accessibilityEnabled: true,
    foregroundListening: true,
    currentApp: 'Home',
    recentAction: 'AccessibilityService connected to WindowManager',
    inspectedNodesCount: 14,
    screenshotUrl: null,
    scannedQrCode: null
  });

  // API Settings (Encrypted DataStore)
  const [apiSettings, setApiSettings] = useState<ApiSettingsState>({
    apiKey: '',
    model: 'gemini-3.8-flash',
    voice: 'Charon',
    pitch: 0.72,
    speechRate: 0.96,
    encrypted: true,
    alwaysListening: true
  });

  // Speech Recognition Reference
  const recognitionRef = useRef<any>(null);

  // Web Speech Synthesis Deep Male Voice Synthesizer
  const speakDeepVoice = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    // Find deep male voice if available
    const voices = window.speechSynthesis.getVoices();
    const deepMaleVoice = voices.find(
      (v) =>
        v.name.includes('Male') ||
        v.name.includes('David') ||
        v.name.includes('Daniel') ||
        v.name.includes('Google UK English Male') ||
        v.name.includes('Natural')
    );

    if (deepMaleVoice) {
      utterance.voice = deepMaleVoice;
    }

    utterance.pitch = apiSettings.pitch; // Deep baritone tone
    utterance.rate = apiSettings.speechRate;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, [apiSettings.pitch, apiSettings.speechRate]);

  // Handle Command Execution (Phone & PC)
  const executeTacticalAction = useCallback((commandText: string) => {
    const lower = commandText.toLowerCase();

    // 1. PC Mouse Move Commands
    if (lower.includes('mouse') && lower.includes('pc') || lower.includes('move mouse') || lower.includes('move the mouse')) {
      let dx = 0;
      let dy = 0;
      if (lower.includes('left')) dx = -100;
      else if (lower.includes('right')) dx = 100;
      else if (lower.includes('up')) dy = -80;
      else if (lower.includes('down')) dy = 80;

      setPcState((prev) => ({
        ...prev,
        cursor: {
          x: Math.max(20, Math.min(580, prev.cursor.x + dx)),
          y: Math.max(20, Math.min(360, prev.cursor.y + dy)),
        },
        terminalLogs: [...prev.terminalLogs, `pyautogui.moveRel(${dx}, ${dy}) via Voice`],
        lastAction: `Relocated PC mouse cursor [dx:${dx}, dy:${dy}]`
      }));
      return 'Relocating mouse cursor on PC.';
    }

    // 2. PC Typing Command: "VOID, type this on my PC: ..."
    if (lower.includes('type') && (lower.includes('pc') || lower.includes('computer'))) {
      const match = commandText.replace(/.*type\s+(this\s+on\s+my\s+pc|on\s+my\s+pc|on\s+pc|this)?\s*:?/i, '').trim();
      const textToType = match || 'VOID_INJECTION_ACTIVE';
      setPcState((prev) => ({
        ...prev,
        terminalLogs: [...prev.terminalLogs, `pyautogui.typewrite("${textToType}")`],
        lastAction: `Typed "${textToType}" on PC workstation`
      }));
      return `Typed "${textToType}" on target PC.`;
    }

    // 3. PC Click Command
    if (lower.includes('click') && (lower.includes('pc') || lower.includes('mouse'))) {
      setPcState((prev) => ({
        ...prev,
        terminalLogs: [...prev.terminalLogs, `pyautogui.click() at (${prev.cursor.x}, ${prev.cursor.y})`],
        lastAction: 'Dispatched mouse left-click on PC'
      }));
      return 'Mouse click executed on PC.';
    }

    // 4. Phone Launch App Command: "Open Instagram", "Open Chrome"
    if (lower.includes('open') || lower.includes('launch')) {
      const target = lower.replace(/.*(open|launch)\s+/i, '').trim();
      let detectedApp = 'Instagram';
      if (target.includes('chrome') || target.includes('browser')) detectedApp = 'Chrome';
      else if (target.includes('qr') || target.includes('scanner')) detectedApp = 'QR Scanner';
      else if (target.includes('message')) detectedApp = 'Messages';
      else if (target.includes('home')) detectedApp = 'Home';

      setPhoneState((prev) => ({
        ...prev,
        currentApp: detectedApp,
        recentAction: `Accessibility: Launched ${detectedApp} (package: com.${detectedApp.toLowerCase()})`
      }));
      return `Accessibility service launched ${detectedApp}.`;
    }

    // 5. Phone Screenshot Command
    if (lower.includes('screenshot') || lower.includes('capture screen')) {
      const simulatedUrl = '/src/assets/images/void_ai_avatar_1793160475276.jpg';
      setPhoneState((prev) => ({
        ...prev,
        screenshotUrl: simulatedUrl,
        recentAction: 'MediaProjection API: Captured 1080x2400 screenshot buffer'
      }));
      return 'Display buffer captured. Screenshot saved.';
    }

    // 6. Phone Scroll Command
    if (lower.includes('scroll')) {
      const isUp = lower.includes('up');
      setPhoneState((prev) => ({
        ...prev,
        recentAction: `Accessibility: Dispatched gesture swipe (${isUp ? 'UP' : 'DOWN'})`
      }));
      return `Scrolled phone display ${isUp ? 'upward' : 'downward'}.`;
    }

    // 7. QR Scanner Command
    if (lower.includes('qr') || lower.includes('scan')) {
      setPhoneState((prev) => ({
        ...prev,
        currentApp: 'QR Scanner',
        scannedQrCode: 'VOID_CIPHER_KEY::AUTH_GRANTED_2026',
        recentAction: 'CameraX / ZXing: QR Code decoded into memory'
      }));
      return 'QR code scanned and decoded into memory context.';
    }

    return null;
  }, []);

  // Execute Multi-Step Voice Macro Sequence
  const executeMacroSequence = useCallback(async (macro: VoiceMacro) => {
    setExecutingMacroId(macro.id);
    setTranscript(`VOID, ${macro.triggerPhrase}`);

    // Update macro execution stats
    setMacros(prev => prev.map(m => m.id === macro.id ? { ...m, executionCount: m.executionCount + 1, lastTriggered: Date.now() } : m));

    let finalSpeech = `Executing tactical macro: "${macro.triggerPhrase}". All sequences initiated.`;

    for (const act of macro.actions) {
      await new Promise(r => setTimeout(r, 450));
      switch (act.type) {
        case 'open_app':
          if (act.payload.app) {
            setPhoneState(prev => ({
              ...prev,
              currentApp: act.payload.app!,
              recentAction: `Macro Sequence: Launched ${act.payload.app}`
            }));
          }
          break;
        case 'connect_pc':
          setPcState(prev => ({
            ...prev,
            connected: !!act.payload.connect,
            terminalLogs: [...prev.terminalLogs, act.payload.connect ? '[MACRO] QuickTrip PC Cloud connected.' : '[MACRO] PC link terminated.']
          }));
          break;
        case 'pc_type':
          if (act.payload.text) {
            setPcState(prev => ({
              ...prev,
              terminalLogs: [...prev.terminalLogs, `pyautogui.typewrite("${act.payload.text}")`],
              lastAction: `Macro: Typed "${act.payload.text}" on PC`
            }));
          }
          break;
        case 'pc_shortcut':
          if (act.payload.key) {
            setPcState(prev => ({
              ...prev,
              terminalLogs: [...prev.terminalLogs, `pyautogui.hotkey("${act.payload.key}")`],
              lastAction: `Macro Shortcut: ${act.payload.key}`
            }));
          }
          break;
        case 'set_voice_tone':
          if (act.payload.pitch) {
            setApiSettings(prev => ({ ...prev, pitch: act.payload.pitch! }));
          }
          break;
        case 'take_screenshot':
          setPhoneState(prev => ({
            ...prev,
            screenshotUrl: '/src/assets/images/void_hooded_cyborg_1793161662943.jpg',
            recentAction: 'Macro: Captured 1080x2400 screenshot buffer'
          }));
          break;
        case 'scroll_screen':
          setPhoneState(prev => ({
            ...prev,
            recentAction: `Macro: Dispatched scroll gesture (${(act.payload.direction || 'down').toUpperCase()})`
          }));
          break;
        case 'speak_phrase':
          if (act.payload.message) {
            finalSpeech = act.payload.message;
          }
          break;
      }
    }

    setAssistantReply(finalSpeech);
    speakDeepVoice(finalSpeech);

    // Save macro execution in Room DB
    const macroLog: ConversationItem = {
      id: `macro_exec_${Date.now()}`,
      role: 'model',
      text: `[VOICE MACRO EXECUTED]: "${macro.triggerPhrase}" (${macro.actions.length} actions). ${finalSpeech}`,
      timestamp: Date.now(),
      model: apiSettings.model,
      voice: apiSettings.voice,
      bytes: 240,
      actionTaken: `Voice Macro "${macro.triggerPhrase}" Completed`
    };
    setConversations(prev => [macroLog, ...prev]);

    setExecutingMacroId(null);
  }, [apiSettings.model, apiSettings.voice, speakDeepVoice]);

  // Process User Input through Gemini API
  const handleProcessVoiceInput = useCallback(async (userPrompt: string) => {
    if (!userPrompt.trim()) return;

    setIsProcessing(true);
    setTranscript(userPrompt);

    // Check if prompt triggers a custom multi-step Voice Macro
    const cleanLower = userPrompt.toLowerCase().replace(/^void,?\s*/i, '').trim();
    const matchedMacro = macros.find(m => 
      m.enabled && (
        cleanLower === m.triggerPhrase.toLowerCase() || 
        userPrompt.toLowerCase().includes(m.triggerPhrase.toLowerCase()) ||
        cleanLower.includes(m.triggerPhrase.toLowerCase())
      )
    );

    if (matchedMacro) {
      await executeMacroSequence(matchedMacro);
      setIsProcessing(false);
      return;
    }

    // Check if user is asking VOID to code / write scripts
    if (
      cleanLower.startsWith('write a ') || 
      cleanLower.startsWith('code a ') || 
      cleanLower.startsWith('write code') || 
      cleanLower.startsWith('create a script') ||
      cleanLower.includes('write script') ||
      cleanLower.includes('code script')
    ) {
      let lang = 'python';
      if (cleanLower.includes('bash') || cleanLower.includes('shell')) lang = 'bash';
      else if (cleanLower.includes('powershell')) lang = 'powershell';
      else if (cleanLower.includes('javascript') || cleanLower.includes('node')) lang = 'javascript';
      else if (cleanLower.includes('typescript')) lang = 'typescript';
      else if (cleanLower.includes('kotlin')) lang = 'kotlin';
      else if (cleanLower.includes('rust')) lang = 'rust';
      else if (cleanLower.includes('sql')) lang = 'sql';

      setActiveScreen('codestudio');
      handleGenerateCode(userPrompt, lang);
      const ack = `Synthesizing ${lang} code. Launching AI Coding Studio.`;
      setAssistantReply(ack);
      speakDeepVoice(ack);

      const codeLog: ConversationItem = {
        id: `code_req_${Date.now()}`,
        role: 'model',
        text: `[AI CODING DIRECTIVE]: "${userPrompt}". Code Studio active.`,
        timestamp: Date.now(),
        model: apiSettings.model,
        voice: apiSettings.voice,
        bytes: 180,
        actionTaken: 'AI Code Studio Activated'
      };
      setConversations(prev => [codeLog, ...prev]);

      setIsProcessing(false);
      return;
    }

    // Save user message to Room DB
    const userItem: ConversationItem = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: userPrompt,
      timestamp: Date.now(),
      model: apiSettings.model,
      voice: apiSettings.voice,
      bytes: userPrompt.length * 2
    };

    setConversations((prev) => [userItem, ...prev]);

    // Check for local tactical command triggers first
    const actionResult = executeTacticalAction(userPrompt);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userPrompt,
          history: conversations.slice(0, 5),
          customApiKey: apiSettings.apiKey,
          voice: apiSettings.voice,
          pcStatus: { connected: pcState.connected, ip: pcState.ip },
          phoneState: { accessibilityEnabled: phoneState.accessibilityEnabled, currentApp: phoneState.currentApp }
        })
      });

      const data = await res.json();
      let replyText = data.reply || "Command acknowledged. Standing by.";

      if (actionResult && !replyText.includes(actionResult)) {
        replyText = `${actionResult} ${replyText}`;
      }

      setAssistantReply(replyText);

      // Save assistant message to Room DB
      const assistantItem: ConversationItem = {
        id: `void_${Date.now()}`,
        role: 'model',
        text: replyText,
        timestamp: Date.now(),
        model: apiSettings.model,
        voice: apiSettings.voice,
        bytes: replyText.length * 2,
        actionTaken: actionResult || 'Conversational Response'
      };

      setConversations((prev) => [assistantItem, ...prev]);

      // Speak in deep male voice
      speakDeepVoice(replyText);

    } catch (err) {
      console.error(err);
      const fallbackReply = actionResult || "Command processed on local tactical buffer. Standing by.";
      setAssistantReply(fallbackReply);
      speakDeepVoice(fallbackReply);
    } finally {
      setIsProcessing(false);
    }
  }, [conversations, apiSettings, pcState, phoneState, executeTacticalAction, speakDeepVoice, macros, executeMacroSequence]);

  // Microphone Toggle & Web Speech Recognition Init
  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
    } else {
      setTranscript('');
      setAssistantReply('');

      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        try {
          const recognition = new SpeechRecognition();
          recognition.continuous = false;
          recognition.interimResults = true;
          recognition.lang = 'en-US';

          recognition.onstart = () => {
            setIsListening(true);
          };

          recognition.onresult = (event: any) => {
            const current = event.resultIndex;
            const text = event.results[current][0].transcript;
            setTranscript(text);

            if (event.results[current].isFinal) {
              handleProcessVoiceInput(text);
              setIsListening(false);
            }
          };

          recognition.onerror = (err: any) => {
            console.warn('Speech recognition error:', err);
            setIsListening(false);
          };

          recognition.onend = () => {
            setIsListening(false);
          };

          recognitionRef.current = recognition;
          recognition.start();
        } catch (e) {
          console.error('Speech recognition failed to start:', e);
          setIsListening(false);
        }
      } else {
        // Fallback simulated voice trigger
        setIsListening(true);
        setTimeout(() => {
          setIsListening(false);
          handleProcessVoiceInput("VOID, status report and check PC Cloud connection");
        }, 1800);
      }
    }
  };

  // Quick Command Trigger
  const handleQuickCommand = (cmd: string) => {
    setTranscript(cmd);
    handleProcessVoiceInput(cmd);
  };

  // PC Cloud Handlers
  const handlePcConnectToggle = () => {
    setPcState((prev) => ({
      ...prev,
      connected: !prev.connected,
      terminalLogs: [
        ...prev.terminalLogs,
        prev.connected ? 'Connection terminated.' : 'QuickTrip link established.'
      ]
    }));
  };

  const handlePcMoveCursor = (dx: number, dy: number) => {
    setPcState((prev) => ({
      ...prev,
      cursor: {
        x: Math.max(10, Math.min(620, prev.cursor.x + dx)),
        y: Math.max(10, Math.min(390, prev.cursor.y + dy)),
      },
      terminalLogs: [...prev.terminalLogs, `pyautogui.moveRel(${dx}, ${dy})`]
    }));
  };

  const handlePcClick = () => {
    setPcState((prev) => ({
      ...prev,
      terminalLogs: [...prev.terminalLogs, `pyautogui.click() at (${prev.cursor.x}, ${prev.cursor.y})`],
      lastAction: 'Mouse Click'
    }));
  };

  const handlePcTypeText = (text: string) => {
    setPcState((prev) => ({
      ...prev,
      terminalLogs: [...prev.terminalLogs, `pyautogui.typewrite("${text}")`],
      lastAction: `Typed "${text}"`
    }));
  };

  const handlePcShortcut = (key: string) => {
    setPcState((prev) => ({
      ...prev,
      terminalLogs: [...prev.terminalLogs, `pyautogui.hotkey("${key}")`],
      lastAction: `Shortcut: ${key}`
    }));
  };

  // Phone Accessibility Handlers
  const handleToggleAccessibility = () => {
    setPhoneState((prev) => ({
      ...prev,
      accessibilityEnabled: !prev.accessibilityEnabled,
      recentAction: !prev.accessibilityEnabled
        ? 'Accessibility Service granted and bound'
        : 'Accessibility Service disconnected'
    }));
  };

  const handlePhoneLaunchApp = (app: string) => {
    setPhoneState((prev) => ({
      ...prev,
      currentApp: app,
      recentAction: `Accessibility: Launched ${app}`
    }));
  };

  const handlePhoneClick = (target: string) => {
    setPhoneState((prev) => ({
      ...prev,
      recentAction: `Accessibility: Dispatched ACTION_CLICK on '${target}'`
    }));
  };

  const handlePhoneScroll = (dir: 'up' | 'down') => {
    setPhoneState((prev) => ({
      ...prev,
      recentAction: `Accessibility: Dispatched scroll gesture (${dir.toUpperCase()})`
    }));
  };

  const handlePhoneType = (text: string) => {
    setPhoneState((prev) => ({
      ...prev,
      recentAction: `Accessibility: Injected text '${text}' into active input`
    }));
  };

  const handlePhoneScreenshot = () => {
    setPhoneState((prev) => ({
      ...prev,
      screenshotUrl: '/src/assets/images/void_ai_avatar_1793160475276.jpg',
      recentAction: 'MediaProjection API: Captured 1080x2400 screenshot buffer'
    }));
  };

  const handlePhoneScanQr = () => {
    setPhoneState((prev) => ({
      ...prev,
      currentApp: 'QR Scanner',
      scannedQrCode: 'VOID_CYBER_TOKEN_7782_VALIDATED',
      recentAction: 'ZXing: Decoded QR matrix payload'
    }));
  };

  // Memory Handlers
  const handleClearMemory = () => {
    setConversations([]);
  };

  const handleDeleteConversation = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
  };

  // Test Deep Voice
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const handleTestVoice = () => {
    setIsTestingVoice(true);
    const testPhrase = `I am VOID. Neural engine online. Voice persona set to ${apiSettings.voice}. Standing by for tactical directives.`;
    speakDeepVoice(testPhrase);
    setTimeout(() => setIsTestingVoice(false), 3000);
  };

  return (
    <div className="w-full min-h-screen bg-black text-white font-sans antialiased overflow-x-hidden">
      
      {/* THREE-LAYER NAVIGATION DRAWER */}
      <NavigationDrawer
        isOpen={isDrawerOpen}
        activeScreen={activeScreen}
        onSelectScreen={setActiveScreen}
        onClose={() => setIsDrawerOpen(false)}
        isOnline={true}
      />

      {/* TOP COMPACT APPLET HEADER (When not on home screen) */}
      {activeScreen !== 'home' && (
        <header className="sticky top-0 z-30 bg-black/95 backdrop-blur-md border-b border-white/10 px-4 md:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsDrawerOpen(true)}
              className="p-2 rounded-lg bg-zinc-900 border border-white/10 text-white hover:bg-zinc-800 transition-colors"
              aria-label="Open Navigation Drawer"
            >
              <span className="sr-only">Menu</span>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div className="flex items-center gap-2">
              <span className="text-base font-extrabold tracking-widest text-white font-display">VOID.AI</span>
              <span className="text-zinc-600">/</span>
              <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                {activeScreen}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveScreen('home')}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-mono text-zinc-300 hover:text-white transition-all"
            >
              Back to Home
            </button>
          </div>
        </header>
      )}

      {/* ACTIVE SCREEN ROUTER */}
      {activeScreen === 'home' && (
        <HomeScreenView
          onOpenDrawer={() => setIsDrawerOpen(true)}
          isListening={isListening}
          isSpeaking={isSpeaking}
          onToggleMic={toggleListening}
          transcript={transcript}
          assistantReply={assistantReply}
          isProcessing={isProcessing}
          onQuickCommand={handleQuickCommand}
          voicePersona={apiSettings.voice}
          connectedToPc={pcState.connected}
          accessibilityActive={phoneState.accessibilityEnabled}
          avatarImageUrl={avatarImageUrl}
          onChangeAvatarClick={() => setIsChangeAvatarOpen(true)}
        />
      )}

      {activeScreen === 'pccloud' && (
        <PcCloudScreenView
          pcState={pcState}
          onConnectToggle={handlePcConnectToggle}
          onMoveCursor={handlePcMoveCursor}
          onClickCursor={handlePcClick}
          onTypeText={handlePcTypeText}
          onShortcut={handlePcShortcut}
        />
      )}

      {activeScreen === 'phoneaccessibility' && (
        <PhoneAccessibilityScreenView
          phoneState={phoneState}
          onToggleAccessibility={handleToggleAccessibility}
          onLaunchApp={handlePhoneLaunchApp}
          onPerformClick={handlePhoneClick}
          onPerformScroll={handlePhoneScroll}
          onPerformType={handlePhoneType}
          onTakeScreenshot={handlePhoneScreenshot}
          onScanQr={handlePhoneScanQr}
        />
      )}

      {activeScreen === 'memory' && (
        <MemoryScreenView
          conversations={conversations}
          onClearMemory={handleClearMemory}
          onDeleteConversation={handleDeleteConversation}
          totalBytesUsed={totalBytesUsed}
        />
      )}

      {activeScreen === 'apisettings' && (
        <ApiSettingsScreenView
          settings={apiSettings}
          onUpdateSettings={(s) => setApiSettings((prev) => ({ ...prev, ...s }))}
          onTestVoice={handleTestVoice}
          isTestingVoice={isTestingVoice}
        />
      )}

      {activeScreen === 'permissions' && (
        <PermissionsScreenView
          accessibilityActive={phoneState.accessibilityEnabled}
          onToggleAccessibility={handleToggleAccessibility}
          foregroundActive={phoneState.foregroundListening}
          onToggleForeground={() =>
            setPhoneState((prev) => ({
              ...prev,
              foregroundListening: !prev.foregroundListening
            }))
          }
        />
      )}

      {activeScreen === 'settings' && (
        <SettingsScreenView
          settings={apiSettings}
          onUpdateSettings={(s) => setApiSettings((prev) => ({ ...prev, ...s }))}
          onChangeAvatarClick={() => setIsChangeAvatarOpen(true)}
          macros={macros}
          onAddMacro={handleAddMacro}
          onUpdateMacro={handleUpdateMacro}
          onDeleteMacro={handleDeleteMacro}
          onExecuteMacro={executeMacroSequence}
          executingMacroId={executingMacroId}
        />
      )}

      {activeScreen === 'androidsource' && (
        <AndroidSourceScreenView />
      )}

      {activeScreen === 'codestudio' && (
        <AiCodeStudioScreenView
          onGenerateCode={handleGenerateCode}
          isGenerating={isGeneratingCode}
          history={codeHistory}
          onSendToPc={handleSendCodeToPc}
          onExecuteOnPc={handleExecuteOnPc}
          pcState={pcState}
        />
      )}

      {/* CHANGE AVATAR & IMAGE UPLOAD MODAL */}
      <ChangeAvatarModal
        isOpen={isChangeAvatarOpen}
        currentImageUrl={avatarImageUrl}
        onSelectImage={handleSelectAvatar}
        onClose={() => setIsChangeAvatarOpen(false)}
      />

    </div>
  );
}
