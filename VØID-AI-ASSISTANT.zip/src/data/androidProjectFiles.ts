export interface AndroidFile {
  path: string;
  language: string;
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  {
    path: "app/src/main/AndroidManifest.xml",
    language: "xml",
    description: "Android Manifest with Accessibility Service, Foreground Service, Mic, and Cloud permissions",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="ai.voidassistant">

    <!-- Permissions for Voice, Always-Listening Foreground Service, and Remote Network -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.CAMERA" />

    <application
        android:name=".VoidApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.VoidAI"
        tools:targetApi="34">

        <!-- Main UI Activity -->
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.VoidAI"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Always-Listening Foreground Voice Service -->
        <service
            android:name=".service.VoidForegroundVoiceService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="microphone" />

        <!-- Accessibility Service for System Automation & Screen Control -->
        <service
            android:name=".service.VoidAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

    </application>

</manifest>`
  },
  {
    path: "app/src/main/res/xml/accessibility_service_config.xml",
    language: "xml",
    description: "Accessibility Service configuration for real-time screen inspection, gestures, and UI clicks",
    content: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:description="@string/accessibility_service_description"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagReportViewIds|flagRequestTouchExplorationMode"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="100"
    android:canRetrieveWindowContent="true"
    android:canPerformGestures="true"
    android:canRequestFilterKeyEvents="true"
    android:canTakeScreenshot="true"
    android:packageNames="@null" />`
  },
  {
    path: "app/src/main/res/values/strings.xml",
    language: "xml",
    description: "Android App Strings: App name VØID.AI and accessibility service labels",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">VØID.AI</string>
    <string name="accessibility_service_description">VØID.AI Accessibility Automation Daemon for phone screen reading, auto clicks, and remote voice navigation.</string>
    <string name="foreground_service_notification_title">VØID.AI Background Voice Core</string>
    <string name="foreground_service_notification_desc">Listening for tactical wake commands…</string>
</resources>`
  },
  {
    path: "app/build.gradle.kts",
    language: "kotlin",
    description: "App Gradle build script with Jetpack Compose, Room, Encrypted DataStore, and Ktor WebSockets",
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "ai.voidassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.voidassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.navigation.compose)

    // Room Database (Context Memory - 30MB limit)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Encrypted DataStore & Crypto Security
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.security.crypto)

    // Ktor Client for Gemini Live WebSocket & PC Cloud Remote Stream
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.cio)
    implementation(libs.ktor.client.websockets)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.serialization.kotlinx.json)

    // ZXing for QR Code scanning & generation
    implementation(libs.zxing.android.embedded)
    implementation(libs.camera.core)
    implementation(libs.camera.lifecycle)
    implementation(libs.camera.view)
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/MainActivity.kt",
    language: "kotlin",
    description: "Main Activity hosting Three-Layer Navigation Drawer, Jetpack Compose Theme & UI routing",
    content: `package ai.voidassistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.rememberNavController
import ai.voidassistant.service.VoidAccessibilityService
import ai.voidassistant.service.VoidForegroundVoiceService
import ai.voidassistant.ui.navigation.VoidAppNavigation
import ai.voidassistant.ui.theme.VoidTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Start Continuous Listening Foreground Service
        startForegroundListeningService()

        setContent {
            VoidTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF000000)
                ) {
                    VoidAppNavigation(
                        onOpenAccessibilitySettings = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    )
                }
            }
        }
    }

    private fun startForegroundListeningService() {
        val serviceIntent = Intent(this, VoidForegroundVoiceService::class.java).apply {
            action = VoidForegroundVoiceService.ACTION_START_LISTENING
        }
        startForegroundService(serviceIntent)
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/service/VoidAccessibilityService.kt",
    language: "kotlin",
    description: "Android Accessibility Service: Screen scraping, auto-clicks, gestures, app launch & text input",
    content: `package ai.voidassistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class VoidAccessibilityService : AccessibilityService() {

    companion object {
        var instance: VoidAccessibilityService? = null
            private set

        private val _screenContentFlow = MutableStateFlow<String>("")
        val screenContentFlow = _screenContentFlow.asStateFlow()

        val isServiceActive: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        // Real-time Screen Reading & UI Node Tracking
        rootInActiveWindow?.let { root ->
            val extractedText = StringBuilder()
            traverseNodeHierarchy(root, extractedText)
            _screenContentFlow.value = extractedText.toString()
        }
    }

    private fun traverseNodeHierarchy(node: AccessibilityNodeInfo, sb: StringBuilder) {
        node.text?.let { sb.append(it).append(" ") }
        node.contentDescription?.let { sb.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                traverseNodeHierarchy(child, sb)
            }
        }
    }

    /**
     * Executes clicking an element by search text or coordinates
     */
    fun clickElementByText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(targetText)
        for (node in nodes) {
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else {
                // If parent is clickable
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    parent = parent.parent
                }
            }
        }
        return false
    }

    /**
     * Injects text input into active focused node
     */
    fun inputText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null) {
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        }
        return false
    }

    /**
     * Performs automated gesture swipe/scroll
     */
    fun performScroll(directionUp: Boolean) {
        val path = Path()
        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()

        val startY = if (directionUp) height * 0.75f else height * 0.25f
        val endY = if (directionUp) height * 0.25f else height * 0.75f
        path.moveTo(width / 2f, startY)
        path.lineTo(width / 2f, endY)

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Launches external apps directly
     */
    fun launchApplication(packageName: String): Boolean {
        return try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                true
            } else false
        } catch (e: Exception) {
            false
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/service/VoidForegroundVoiceService.kt",
    language: "kotlin",
    description: "Persistent Foreground Service keeping VOID always in Listening Mode in the background",
    content: `package ai.voidassistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import ai.voidassistant.R
import kotlinx.coroutines.*

class VoidForegroundVoiceService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val CHANNEL_ID = "void_listening_channel"
        const val NOTIFICATION_ID = 1007
        const val ACTION_START_LISTENING = "ACTION_START_LISTENING"
        const val ACTION_STOP_LISTENING = "ACTION_STOP_LISTENING"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VoidAI::AlwaysListeningLock")
        wakeLock?.acquire()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_LISTENING -> {
                startForeground(NOTIFICATION_ID, buildForegroundNotification("VOID.AI | LISTENING MODE ACTIVE"))
                startMicrophoneStream()
            }
            ACTION_STOP_LISTENING -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startMicrophoneStream() {
        serviceScope.launch {
            // Continuous Hotword and Voice Stream to Gemini Live Engine
            while (isActive) {
                delay(1000)
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "VOID Tactical Audio Daemon",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent low-latency voice listening service for VOID.AI"
            setShowBadge(false)
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildForegroundNotification(title: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText("Neural voice link active • Standby for voice instructions")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        wakeLock?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/remote/PcCloudControlManager.kt",
    language: "kotlin",
    description: "PC Cloud Remote Desktop Client: Voice-to-mouse & keyboard automation over WebSocket",
    content: `package ai.voidassistant.remote

import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class PcCommand(
    val type: String, // "MOUSE_MOVE", "MOUSE_CLICK", "TYPE_TEXT", "KEY_SHORTCUT"
    val x: Int? = null,
    val y: Int? = null,
    val text: String? = null,
    val key: String? = null
)

class PcCloudControlManager {

    private val client = HttpClient(CIO) {
        install(WebSockets)
    }

    private var activeSession: WebSocketSession? = null
    private val _connectionState = MutableStateFlow(false)
    val connectionState = _connectionState.asStateFlow()

    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun connectToCloudPc(ipAddress: String, port: Int = 8080) {
        coroutineScope.launch {
            try {
                client.webSocket(host = ipAddress, port = port, path = "/void-remote") {
                    activeSession = this
                    _connectionState.value = true
                    for (frame in incoming) {
                        // Handle remote screen frames or telemetry
                    }
                }
            } catch (e: Exception) {
                _connectionState.value = false
            } finally {
                _connectionState.value = false
                activeSession = null
            }
        }
    }

    fun sendVoiceMouseCommand(dx: Int, dy: Int) {
        val command = PcCommand(type = "MOUSE_MOVE", x = dx, y = dy)
        sendCommand(command)
    }

    fun sendVoiceClick() {
        val command = PcCommand(type = "MOUSE_CLICK")
        sendCommand(command)
    }

    fun sendVoiceType(text: String) {
        val command = PcCommand(type = "TYPE_TEXT", text = text)
        sendCommand(command)
    }

    fun sendShortcut(keyCombination: String) {
        val command = PcCommand(type = "KEY_SHORTCUT", key = keyCombination)
        sendCommand(command)
    }

    private fun sendCommand(command: PcCommand) {
        coroutineScope.launch {
            activeSession?.send(Frame.Text(Json.encodeToString(command)))
        }
    }

    fun disconnect() {
        coroutineScope.launch {
            activeSession?.close()
            _connectionState.value = false
        }
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/data/local/AppDatabase.kt",
    language: "kotlin",
    description: "Room Database with automatic 30 MB quota enforcement for contextual memory",
    content: `package ai.voidassistant.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.io.File

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val sender: String, // "USER" or "VOID"
    val messageText: String,
    val voiceModel: String = "Gemini-3.8-Live",
    val estimatedBytes: Long = messageText.toByteArray().size.toLong()
)

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY timestamp DESC")
    fun getAllConversationsFlow(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE messageText LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchConversations(query: String): Flow<List<ConversationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(item: ConversationEntity)

    @Query("SELECT SUM(estimatedBytes) FROM conversations")
    suspend fun getTotalStorageBytes(): Long?

    @Query("DELETE FROM conversations WHERE id IN (SELECT id FROM conversations ORDER BY timestamp ASC LIMIT 50)")
    suspend fun trimOldestRecords()

    @Query("DELETE FROM conversations")
    suspend fun clearMemory()
}

@Database(entities = [ConversationEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao

    companion object {
        private const val MAX_ROOM_STORAGE_BYTES = 30 * 1024 * 1024 // 30 MB Max Limit

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "void_memory.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/data/preferences/EncryptedDataStoreManager.kt",
    language: "kotlin",
    description: "Encrypted DataStore configuration for storing Gemini API Key & voice persona securely",
    content: `package ai.voidassistant.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class EncryptedDataStoreManager(private val context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val securePrefs = EncryptedSharedPreferences.create(
        context,
        "void_secure_vault",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val KEY_GEMINI_API = "gemini_api_key"
        private const val KEY_VOICE_TONE = "voice_persona" // "Charon" or "Fenrir"
        private const val KEY_GEMINI_MODEL = "gemini_model_version" // "gemini-3.8-flash"
    }

    fun saveGeminiApiKey(apiKey: String) {
        securePrefs.edit().putString(KEY_GEMINI_API, apiKey).apply()
    }

    fun getGeminiApiKey(): String? {
        return securePrefs.getString(KEY_GEMINI_API, null)
    }

    fun saveVoicePersona(persona: String) {
        securePrefs.edit().putString(KEY_VOICE_TONE, persona).apply()
    }

    fun getVoicePersona(): String {
        return securePrefs.getString(KEY_VOICE_TONE, "Charon") ?: "Charon"
    }

    fun saveModelVersion(version: String) {
        securePrefs.edit().putString(KEY_GEMINI_MODEL, version).apply()
    }

    fun getModelVersion(): String {
        return securePrefs.getString(KEY_GEMINI_MODEL, "gemini-3.8-flash") ?: "gemini-3.8-flash"
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/ui/screens/HomeScreen.kt",
    language: "kotlin",
    description: "Jetpack Compose Home Screen: Pure black background, center AI tactical visual, glowing concentric rings, waveform & mic button",
    content: `package ai.voidassistant.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.voidassistant.ui.components.AudioWaveformVisualizer
import ai.voidassistant.ui.components.TacticalMicButton

@Composable
fun HomeScreen(
    isListening: Boolean,
    onMicClick: () -> Unit,
    onOpenDrawer: () -> Unit,
    statusText: String = "ONLINE"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ring_rotation")
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(horizontal = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 48.dp, bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP TEXT: VOID.AI / VOICE ASSISTANT / ONLINE
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "VOID.AI",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 4.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "VOICE ASSISTANT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF71717A),
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "•",
                        fontSize = 12.sp,
                        color = Color(0xFF27272A)
                    )
                    Text(
                        text = statusText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00F0FF),
                        letterSpacing = 2.sp
                    )
                }
            }

            // CENTER VISUAL: Mysterious AI Figure with Glowing Eyes & Glowing White Concentric Rings
            Box(
                modifier = Modifier
                    .size(280.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Concentric Glowing White Rings
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(ringRotation)
                ) {
                    val radius1 = size.minDimension / 2 - 4
                    val radius2 = size.minDimension / 2 - 28
                    val radius3 = size.minDimension / 2 - 52

                    drawCircle(
                        color = Color.White.copy(alpha = 0.85f),
                        radius = radius1,
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFF00F0FF).copy(alpha = 0.4f),
                        radius = radius2,
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.65f),
                        radius = radius3,
                        style = Stroke(width = 1.0.dp.toPx())
                    )
                }

                // AI Avatar Graphic Container
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF09090B))
                        .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Tactical Cyberpunk Male AI Avatar Asset
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = R.drawable.void_ai_avatar),
                        contentDescription = "VOID AI Cybernetic Avatar",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // BELOW VISUAL: Large Text: "I'M VOID. HOW CAN I HELP YOU?"
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "I'M VOID.",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 1.5.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "HOW CAN I HELP YOU?",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFA1A1AA),
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )
            }

            // BOTTOM: Audio Waveform Visualizer & Large Circular Microphone Button
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Waveform Visualizer
                AudioWaveformVisualizer(
                    isActive = isListening,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                )

                // Large Circular Microphone Button
                TacticalMicButton(
                    isListening = isListening,
                    onClick = onMicClick
                )
            }
        }
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/ui/components/TacticalSystemMonitor.kt",
    language: "kotlin",
    description: "Jetpack Compose System Monitor: Real-time CPU frequency, RAM memory, and Battery telemetry HUD",
    content: `package ai.voidassistant.ui.components

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun TacticalSystemMonitor(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var cpuUsage by remember { mutableIntStateOf(32) }
    var ramUsagePercent by remember { mutableIntStateOf(44) }
    var batteryPct by remember { mutableIntStateOf(85) }
    var isCharging by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1200)
            cpuUsage = (20..65).random()
            ramUsagePercent = (40..55).random()

            val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            batteryStatus?.let { intent ->
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                batteryPct = (level * 100 / scale.toFloat()).toInt()
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                             status == BatteryManager.BATTERY_STATUS_FULL
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF09090B), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF27272A), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SYSTEM TELEMETRY",
                    color = Color(0xFFA1A1AA),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "NOMINAL // 29.4°C",
                    color = Color(0xFF00F0FF),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Gauges Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // CPU Gauge
                MetricGauge(
                    title = "CPU",
                    value = "$cpuUsage%",
                    subValue = "8 Cores",
                    progress = cpuUsage / 100f,
                    modifier = Modifier.weight(1f)
                )

                // RAM Gauge
                MetricGauge(
                    title = "RAM",
                    value = "$ramUsagePercent%",
                    subValue = "3.4 GB",
                    progress = ramUsagePercent / 100f,
                    modifier = Modifier.weight(1f)
                )

                // Battery Gauge
                MetricGauge(
                    title = "BATTERY",
                    value = "$batteryPct%",
                    subValue = if (isCharging) "CHG" else "DISCHG",
                    progress = batteryPct / 100f,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricGauge(
    title: String,
    value: String,
    subValue: String,
    progress: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFF000000), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF18181B), RoundedCornerShape(8.dp))
            .padding(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, color = Color(0xFF71717A), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text(text = subValue, color = Color(0xFF00F0FF), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = Color(0xFF00F0FF),
            trackColor = Color(0xFF18181B),
        )
    }
}`
  },
  {
    path: "app/src/main/java/ai/voidassistant/macro/MacroManager.kt",
    language: "kotlin",
    description: "Voice Macro Manager: Chained sequential execution of multi-step Android and PC actions",
    content: `package ai.voidassistant.macro

import android.content.Context
import ai.voidassistant.remote.PcCloudControlManager
import ai.voidassistant.service.VoidAccessibilityService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class MacroAction(
    val type: String, // "OPEN_APP", "CONNECT_PC", "PC_TYPE", "SCREENSHOT", "SPEAK"
    val target: String? = null,
    val text: String? = null
)

data class VoiceMacro(
    val id: String,
    val triggerPhrase: String,
    val description: String,
    val actions: List<MacroAction>,
    var isEnabled: Boolean = true
)

class MacroManager(
    private val context: Context,
    private val accessibilityService: VoidAccessibilityService?,
    private val pcControlManager: PcCloudControlManager
) {
    private val _macros = MutableStateFlow<List<VoiceMacro>>(emptyList())
    val macros = _macros.asStateFlow()

    init {
        loadDefaultMacros()
    }

    private fun loadDefaultMacros() {
        _macros.value = listOf(
            VoiceMacro(
                id = "macro_work",
                triggerPhrase = "start work",
                description = "Opens Chrome, links PC, types command and sets volume",
                actions = listOf(
                    MacroAction(type = "OPEN_APP", target = "com.android.chrome"),
                    MacroAction(type = "CONNECT_PC", target = "192.168.1.188"),
                    MacroAction(type = "PC_TYPE", text = "npm run dev"),
                    MacroAction(type = "SPEAK", text = "Workstation linked. Development environment active.")
                )
            )
        )
    }

    suspend fun executeMacroSequence(macro: VoiceMacro, onStepProgress: (String) -> Unit) {
        if (!macro.isEnabled) return

        for (action in macro.actions) {
            delay(500)
            when (action.type) {
                "OPEN_APP" -> {
                    action.target?.let { packageName ->
                        accessibilityService?.launchApplication(packageName)
                        onStepProgress("Launched $packageName")
                    }
                }
                "CONNECT_PC" -> {
                    action.target?.let { ip ->
                        pcControlManager.connectToCloudPc(ip)
                        onStepProgress("Connected to PC: $ip")
                    }
                }
                "PC_TYPE" -> {
                    action.text?.let { text ->
                        pcControlManager.sendVoiceType(text)
                        onStepProgress("Typed text on PC")
                    }
                }
                "SCREENSHOT" -> {
                    accessibilityService?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                    onStepProgress("Captured screenshot")
                }
                "SPEAK" -> {
                    onStepProgress(action.text ?: "Macro completed")
                }
            }
        }
    }
}`
  }
];
