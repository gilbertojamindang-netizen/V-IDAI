import React, { useState } from 'react';
import { 
  Smartphone, 
  Eye, 
  Camera, 
  QrCode, 
  Layers, 
  Play, 
  ArrowDown, 
  ArrowUp, 
  Search, 
  Share2, 
  Heart, 
  MessageSquare, 
  Compass, 
  CheckCircle2, 
  AlertCircle,
  Download,
  ScanLine
} from 'lucide-react';
import { PhoneSimulationState } from '../../types';

interface PhoneAccessibilityScreenViewProps {
  phoneState: PhoneSimulationState;
  onToggleAccessibility: () => void;
  onLaunchApp: (app: string) => void;
  onPerformClick: (targetName: string) => void;
  onPerformScroll: (direction: 'up' | 'down') => void;
  onPerformType: (text: string) => void;
  onTakeScreenshot: () => void;
  onScanQr: () => void;
}

export const PhoneAccessibilityScreenView: React.FC<PhoneAccessibilityScreenViewProps> = ({
  phoneState,
  onToggleAccessibility,
  onLaunchApp,
  onPerformClick,
  onPerformScroll,
  onPerformType,
  onTakeScreenshot,
  onScanQr,
}) => {
  const [inputText, setInputText] = useState('');
  const [igLiked, setIgLiked] = useState(false);
  const [qrValue, setQrValue] = useState('VOID_SIGNAL_7782_AUTH_VALID');
  const [activeTab, setActiveTab] = useState<'screen' | 'nodes' | 'qr'>('screen');

  const handleTypeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      onPerformType(inputText.trim());
      setInputText('');
    }
  };

  return (
    <div className="w-full h-full min-h-screen bg-black text-white p-4 md:p-6 flex flex-col gap-5 select-none">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/20 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.2)]">
            <Smartphone className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-wider font-display">ACCESSIBILITY & PHONE CONTROL</h1>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                phoneState.accessibilityEnabled
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  : 'bg-zinc-900 text-zinc-400 border-zinc-700'
              }`}>
                {phoneState.accessibilityEnabled ? 'SERVICE ACTIVE' : 'PERMISSION NEEDED'}
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              Live Screen Reading • Autonomous UI Gestures • Screenshot & QR Engine
            </p>
          </div>
        </div>

        {/* SERVICE TOGGLE */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleAccessibility}
            className={`px-4 py-2 rounded-lg text-xs font-bold font-mono tracking-wider transition-all active:scale-95 flex items-center gap-2 ${
              phoneState.accessibilityEnabled
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500 hover:bg-emerald-500/30'
                : 'bg-cyan-500 text-black hover:bg-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.4)]'
            }`}
          >
            {phoneState.accessibilityEnabled ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>ACCESSIBILITY ENABLED</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-4 h-4" />
                <span>GRANT ACCESSIBILITY</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* ACTION TOOLBAR STRIP */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-950 p-3 rounded-xl border border-white/10 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className="text-zinc-400">CURRENT FOREGROUND APP:</span>
          <span className="px-2 py-0.5 rounded bg-white/10 text-white font-bold">{phoneState.currentApp}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onTakeScreenshot}
            className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-white/15 hover:border-cyan-400 text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all active:scale-95"
          >
            <Camera className="w-3.5 h-3.5 text-cyan-400" />
            <span>Capture Screenshot</span>
          </button>

          <button
            onClick={onScanQr}
            className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-white/15 hover:border-cyan-400 text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all active:scale-95"
          >
            <QrCode className="w-3.5 h-3.5 text-cyan-400" />
            <span>Process QR Code</span>
          </button>
        </div>
      </div>

      {/* SPLIT VIEWPORT: SIMULATED ANDROID DEVICE + NODE TREE INSPECTOR */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: SIMULATED ANDROID PHONE CONTAINER (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          
          {/* Android Smartphone Bezel Chassis */}
          <div className="w-[320px] md:w-[340px] h-[640px] bg-black rounded-[40px] border-4 border-zinc-800 p-3 shadow-2xl relative flex flex-col justify-between overflow-hidden ring-1 ring-white/10">
            
            {/* Top Speaker & Camera Punch Hole */}
            <div className="w-full flex justify-center items-center py-1 absolute top-2 left-0 right-0 z-30 pointer-events-none">
              <div className="w-12 h-4 bg-zinc-900 rounded-full flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-black border border-zinc-700" />
              </div>
            </div>

            {/* Android Screen Glass Viewport */}
            <div className="w-full h-full bg-[#0a0a0c] rounded-[32px] overflow-hidden flex flex-col justify-between relative border border-white/5">
              
              {/* Android Status Bar */}
              <div className="w-full px-5 pt-3 pb-1 flex items-center justify-between text-[10px] font-mono text-zinc-400 z-20 bg-gradient-to-b from-black/80 to-transparent">
                <span>09:42</span>
                <div className="flex items-center gap-2">
                  <span>5G</span>
                  <span>100%</span>
                </div>
              </div>

              {/* ACTIVE APP CONTENT CANVAS */}
              <div className="flex-1 overflow-y-auto p-4 flex flex-col">
                
                {/* 1. LAUNCHER / HOME APP */}
                {phoneState.currentApp === 'Home' && (
                  <div className="flex-1 flex flex-col justify-between pt-4">
                    <div className="text-center space-y-1">
                      <div className="text-2xl font-bold font-mono text-white">09:42</div>
                      <div className="text-xs text-zinc-400 font-mono">Tuesday, October 27</div>
                    </div>

                    {/* App Grid */}
                    <div className="grid grid-cols-4 gap-4 my-auto">
                      {[
                        { name: 'Instagram', icon: '📸', color: 'bg-pink-600' },
                        { name: 'Chrome', icon: '🌐', color: 'bg-blue-600' },
                        { name: 'Messages', icon: '💬', color: 'bg-emerald-600' },
                        { name: 'Maps', icon: '🗺️', color: 'bg-amber-600' },
                        { name: 'Camera', icon: '📷', color: 'bg-purple-600' },
                        { name: 'QR Scanner', icon: '📱', color: 'bg-cyan-600' },
                        { name: 'Terminal', icon: '💻', color: 'bg-zinc-800' },
                        { name: 'Settings', icon: '⚙️', color: 'bg-zinc-700' },
                      ].map((app, i) => (
                        <button
                          key={i}
                          onClick={() => onLaunchApp(app.name)}
                          className="flex flex-col items-center gap-1 group active:scale-90 transition-transform"
                        >
                          <div className={`w-12 h-12 rounded-2xl ${app.color} flex items-center justify-center text-xl shadow-lg border border-white/20 group-hover:ring-2 ring-cyan-400`}>
                            {app.icon}
                          </div>
                          <span className="text-[10px] text-zinc-300 font-medium truncate w-14 text-center">
                            {app.name}
                          </span>
                        </button>
                      ))}
                    </div>

                    {/* Dock */}
                    <div className="bg-white/5 backdrop-blur-md p-2 rounded-2xl flex justify-around border border-white/10 mb-2">
                      <button onClick={() => onLaunchApp('Chrome')} className="p-2">🌐</button>
                      <button onClick={() => onLaunchApp('Messages')} className="p-2">💬</button>
                      <button onClick={() => onLaunchApp('Instagram')} className="p-2">📸</button>
                      <button onClick={() => onLaunchApp('QR Scanner')} className="p-2">📱</button>
                    </div>
                  </div>
                )}

                {/* 2. INSTAGRAM SIMULATED APP */}
                {phoneState.currentApp === 'Instagram' && (
                  <div className="flex-1 flex flex-col justify-between text-xs">
                    <div className="flex items-center justify-between pb-2 border-b border-white/10">
                      <span className="font-bold text-sm tracking-wide">Instagram</span>
                      <button onClick={() => onLaunchApp('Home')} className="text-zinc-400 text-[10px] font-mono">
                        ✕ Exit
                      </button>
                    </div>

                    {/* Post Card */}
                    <div className="py-2 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-[10px] font-bold">
                          V
                        </div>
                        <span className="font-semibold text-xs">void.official</span>
                      </div>

                      {/* Post Photo */}
                      <div className="w-full h-44 rounded-xl bg-zinc-900 overflow-hidden border border-white/10 relative flex items-center justify-center">
                        <img 
                          src="/src/assets/images/void_hooded_cyborg_1793161662943.jpg" 
                          alt="Feed visual" 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-2 left-2 text-[9px] font-mono bg-black/70 px-1.5 py-0.5 rounded text-cyan-300">
                          CYBERNETIC_SYNAPSE_v1
                        </div>
                      </div>

                      {/* Post Actions */}
                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-3">
                          <button 
                            onClick={() => {
                              setIgLiked(!igLiked);
                              onPerformClick('Instagram Like Heart');
                            }}
                            className="p-1"
                          >
                            <Heart className={`w-5 h-5 ${igLiked ? 'fill-rose-500 text-rose-500' : 'text-white'}`} />
                          </button>
                          <button onClick={() => onPerformClick('Comment')} className="p-1">
                            <MessageSquare className="w-5 h-5 text-white" />
                          </button>
                          <Share2 className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-[10px] text-zinc-400 font-mono">1,482 likes</span>
                      </div>

                      <p className="text-[11px] text-zinc-300">
                        <span className="font-bold text-white mr-1.5">void.official</span>
                        Next-gen autonomous voice agents are now live on Android.
                      </p>
                    </div>

                    {/* Automated Comment Input */}
                    <form onSubmit={handleTypeSubmit} className="pt-2 border-t border-white/10 flex gap-1">
                      <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Add a comment as VOID..."
                        className="flex-1 bg-black/60 border border-white/20 rounded-lg px-2 py-1 text-xs text-white focus:border-cyan-400 focus:outline-none font-mono"
                      />
                      <button type="submit" className="px-2 py-1 bg-cyan-500 text-black font-bold text-xs rounded-lg">
                        Post
                      </button>
                    </form>
                  </div>
                )}

                {/* 3. QR SCANNER APP */}
                {phoneState.currentApp === 'QR Scanner' && (
                  <div className="flex-1 flex flex-col justify-between text-xs py-2">
                    <div className="flex items-center justify-between pb-2 border-b border-white/10">
                      <span className="font-bold text-sm">QR Code Camera Scanner</span>
                      <button onClick={() => onLaunchApp('Home')} className="text-zinc-400 text-[10px] font-mono">
                        ✕ Exit
                      </button>
                    </div>

                    <div className="my-auto flex flex-col items-center gap-3">
                      {/* Viewfinder Target */}
                      <div className="relative w-48 h-48 border-2 border-dashed border-cyan-400/80 rounded-2xl flex items-center justify-center bg-black/50 overflow-hidden shadow-[0_0_20px_rgba(0,240,255,0.2)]">
                        <ScanLine className="w-12 h-12 text-cyan-400 animate-pulse" />
                        
                        {/* Scanning Laser Line */}
                        <div className="absolute w-full h-1 bg-cyan-400 shadow-[0_0_10px_#00f0ff] animate-bounce top-1/2" />
                      </div>

                      <div className="text-center">
                        <p className="text-xs text-zinc-300 font-mono font-semibold">
                          Targeting QR Payload
                        </p>
                        <p className="text-[10px] text-zinc-500 font-mono">
                          Auto-focusing camera lens...
                        </p>
                      </div>

                      <button
                        onClick={onScanQr}
                        className="px-4 py-2 bg-cyan-500 text-black font-mono text-xs font-bold rounded-lg hover:bg-cyan-400 transition-all active:scale-95 shadow-[0_0_12px_rgba(0,240,255,0.4)]"
                      >
                        DECODE QR MATRIX
                      </button>
                    </div>

                    {phoneState.scannedQrCode && (
                      <div className="p-2 rounded bg-cyan-950 border border-cyan-800 text-[10px] font-mono text-cyan-300">
                        DECODED: {phoneState.scannedQrCode}
                      </div>
                    )}
                  </div>
                )}

                {/* 4. CHROME / BROWSER APP */}
                {phoneState.currentApp === 'Chrome' && (
                  <div className="flex-1 flex flex-col justify-between text-xs py-2">
                    <div className="flex items-center justify-between pb-2 border-b border-white/10">
                      <span className="font-bold text-sm">Chrome Browser</span>
                      <button onClick={() => onLaunchApp('Home')} className="text-zinc-400 text-[10px] font-mono">
                        ✕ Exit
                      </button>
                    </div>

                    <div className="bg-zinc-900 px-3 py-1.5 rounded-lg border border-white/10 text-[11px] font-mono text-zinc-300 mb-2 truncate">
                      https://void.ai/status
                    </div>

                    <div className="flex-1 bg-black/40 rounded-xl p-3 border border-white/10 space-y-2 overflow-y-auto">
                      <h4 className="text-sm font-bold text-white font-display">VOID Neural Network Online</h4>
                      <p className="text-[11px] text-zinc-300 leading-relaxed">
                        Accessibility Service node injection allows autonomous reading of Android display buffers in real-time.
                      </p>
                      <div className="p-2 rounded bg-zinc-900 border border-white/10 text-[10px] font-mono text-cyan-300">
                        STATUS: ALL SYSTEMS NOMINAL
                      </div>
                    </div>

                    {/* Scroll buttons */}
                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={() => onPerformScroll('up')}
                        className="flex-1 py-1.5 bg-zinc-900 hover:bg-zinc-800 rounded text-xs font-mono flex items-center justify-center gap-1"
                      >
                        <ArrowUp className="w-3.5 h-3.5 text-cyan-400" /> Scroll Up
                      </button>
                      <button
                        onClick={() => onPerformScroll('down')}
                        className="flex-1 py-1.5 bg-zinc-900 hover:bg-zinc-800 rounded text-xs font-mono flex items-center justify-center gap-1"
                      >
                        <ArrowDown className="w-3.5 h-3.5 text-cyan-400" /> Scroll Down
                      </button>
                    </div>
                  </div>
                )}

              </div>

              {/* Android Bottom Gesture Bar */}
              <div className="w-full py-2 flex justify-center items-center z-20">
                <button
                  onClick={() => onLaunchApp('Home')}
                  className="w-24 h-1 bg-white/40 hover:bg-white rounded-full transition-colors active:scale-90"
                  aria-label="Home Gesture"
                />
              </div>

            </div>

          </div>

          <span className="text-[11px] font-mono text-zinc-400 mt-2">
            Simulated Android 15 Runtime • Accessibility Bound
          </span>
        </div>

        {/* RIGHT COLUMN: ACCESSIBILITY NODE INSPECTOR & TELEMETRY (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          
          {/* INSPECTOR CONTROLS TABS */}
          <div className="flex items-center gap-2 border-b border-white/10 pb-2 text-xs font-mono">
            <button
              onClick={() => setActiveTab('screen')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'screen'
                  ? 'bg-white/15 text-white font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Real-time Screen Reader
            </button>
            <button
              onClick={() => setActiveTab('nodes')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'nodes'
                  ? 'bg-white/15 text-white font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Accessibility Node Tree ({phoneState.inspectedNodesCount})
            </button>
            <button
              onClick={() => setActiveTab('qr')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'qr'
                  ? 'bg-white/15 text-white font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              QR Code Processor
            </button>
          </div>

          {/* TAB 1: REAL-TIME SCREEN TEXT EXTRACTION */}
          {activeTab === 'screen' && (
            <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex flex-col gap-3 flex-1">
              <div className="flex items-center justify-between text-xs font-mono text-zinc-300">
                <span className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-cyan-400" />
                  <span>Real-time Screen OCR / Text Extracted by VOID</span>
                </span>
                <span className="text-emerald-400 text-[10px]">MONITORING LIVE</span>
              </div>

              <div className="bg-black/90 p-3 rounded-lg border border-white/10 font-mono text-xs text-zinc-300 min-h-[140px] leading-relaxed">
                <p className="text-zinc-500">// Text stream scanned via AccessibilityNodeInfo tree:</p>
                <p className="text-cyan-300 mt-1">
                  [App: {phoneState.currentApp}] {phoneState.currentApp === 'Instagram' ? 'Instagram feed void.official 1,482 likes Next-gen autonomous voice agents are now live on Android.' : phoneState.currentApp === 'Home' ? '09:42 Tuesday October 27 Instagram Chrome Messages Maps Camera QR Scanner Terminal Settings' : 'VOID Neural Network Online Status: All Systems Nominal'}
                </p>
              </div>

              {/* ACTION LOGS */}
              <div className="border-t border-white/10 pt-2 text-[11px] font-mono">
                <span className="text-zinc-400 block mb-1">LAST EXECUTED ACCESSIBILITY ACTION:</span>
                <div className="px-3 py-2 rounded bg-zinc-900 border border-white/10 text-emerald-400">
                  &gt; {phoneState.recentAction || 'Standing by for voice instruction'}
                </div>
              </div>

              {/* SCREENSHOT PREVIEW IF CAPTURED */}
              {phoneState.screenshotUrl && (
                <div className="border-t border-white/10 pt-2">
                  <div className="flex items-center justify-between mb-2 text-xs font-mono">
                    <span className="text-cyan-400 font-semibold">Captured Screenshot Preview:</span>
                    <a
                      href={phoneState.screenshotUrl}
                      download="void_screenshot.png"
                      className="text-[10px] text-white hover:underline flex items-center gap-1"
                    >
                      <Download className="w-3 h-3" /> Save Image
                    </a>
                  </div>
                  <img
                    src={phoneState.screenshotUrl}
                    alt="Captured screenshot"
                    className="w-40 rounded-lg border border-white/20 shadow-md"
                  />
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ACCESSIBILITY NODE TREE */}
          {activeTab === 'nodes' && (
            <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex flex-col gap-3 flex-1 font-mono text-xs overflow-y-auto max-h-[460px]">
              <div className="text-zinc-400 text-[10px] pb-1 border-b border-white/10">
                ROOT: android.widget.FrameLayout [0, 0][1080, 2400]
              </div>

              <div className="space-y-2 text-[11px]">
                <div className="p-2 rounded bg-zinc-900 border border-white/10">
                  <div className="text-cyan-400 font-bold">Node #1: android.widget.TextView</div>
                  <div className="text-zinc-400">text: "{phoneState.currentApp}" • bounds: [48, 80][400, 140]</div>
                  <div className="text-emerald-400 text-[10px]">clickable: false • visible: true</div>
                </div>

                <div className="p-2 rounded bg-zinc-900 border border-white/10">
                  <div className="text-cyan-400 font-bold">Node #2: android.widget.Button (Search/Action)</div>
                  <div className="text-zinc-400">id: com.android:id/btn_action • bounds: [880, 80][1030, 140]</div>
                  <div className="text-emerald-400 text-[10px]">clickable: true • performAction(ACTION_CLICK) supported</div>
                </div>

                <div className="p-2 rounded bg-zinc-900 border border-white/10">
                  <div className="text-cyan-400 font-bold">Node #3: android.widget.ScrollView</div>
                  <div className="text-zinc-400">bounds: [0, 160][1080, 2200] • scrollable: true</div>
                  <div className="text-emerald-400 text-[10px]">gestures: ACTION_SCROLL_FORWARD / BACKWARD</div>
                </div>

                <div className="p-2 rounded bg-zinc-900 border border-white/10">
                  <div className="text-cyan-400 font-bold">Node #4: android.widget.EditText (Input Field)</div>
                  <div className="text-zinc-400">focusable: true • bounds: [48, 2220][1032, 2340]</div>
                  <div className="text-emerald-400 text-[10px]">supported: ACTION_SET_TEXT</div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: QR CODE PROCESSOR */}
          {activeTab === 'qr' && (
            <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex flex-col gap-3 flex-1 font-mono text-xs">
              <span className="text-zinc-300 font-bold">Autonomous QR Code Engine:</span>
              <p className="text-zinc-400 text-[11px]">
                VOID uses ZXing and CameraX to detect, decode, and execute actions embedded inside QR codes shown on phone screens or external real-world camera feeds.
              </p>

              <div className="p-3 bg-black rounded-lg border border-white/10 flex flex-col gap-2">
                <label className="text-[10px] text-zinc-400 uppercase">Current QR Payload In Memory:</label>
                <div className="p-2 bg-zinc-900 rounded font-bold text-cyan-300 border border-cyan-800">
                  {phoneState.scannedQrCode || 'VOID_AUTH_PAYLOAD::TOKEN_9981'}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={onScanQr}
                  className="px-4 py-2 bg-cyan-500 text-black font-bold rounded-lg hover:bg-cyan-400 transition-all active:scale-95"
                >
                  SIMULATE QR SCAN
                </button>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
