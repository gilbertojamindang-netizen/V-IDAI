import React, { useState } from 'react';
import { Code2, Download, Copy, Check, FileCode, Folder, Terminal, Sparkles } from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../../data/androidProjectFiles';

export const AndroidSourceScreenView: React.FC = () => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const currentFile = ANDROID_PROJECT_FILES[selectedFileIndex];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add each file to its exact folder in the zip
      ANDROID_PROJECT_FILES.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Add top-level README and gradle settings
      zip.file(
        'README.md',
        `# VØID.AI - Advanced Android AI Voice Assistant

A dark cyberpunk AI voice assistant with system-level Android accessibility automation, PC Cloud remote desktop control, Room database context memory, and Gemini Live Voice integration.

## Key Features
1. **Jetpack Compose UI**: Pure black AMOLED theme (#000000), glowing white concentric orbital rings, tactical AI avatar, reactive waveform visualizer, and Three-Layer Navigation Drawer.
2. **Gemini Live Voice Integration**: Low-latency male voice (Charon / Fenrir baritone) via WebSockets.
3. **Always-Listening Foreground Service**: Persistent audio capture daemon with WakeLock.
4. **Android Accessibility Service**: Autonomous UI reading, clicking buttons, scrolling feeds, and injecting keystrokes.
5. **PC Cloud Control (QuickTrip Style)**: Remote desktop mouse & keyboard control via voice commands.
6. **Room Database**: 30 MB SQLite storage quota manager for persistent conversational memory.
7. **Encrypted DataStore**: Hardware-backed AES-256 GCM storage for Gemini API keys.

## Build Instructions
1. Open the unzipped folder in **Android Studio Ladybug (2024.2+)** or newer.
2. Ensure JDK 17 is selected in \`Settings -> Build, Execution, Deployment -> Build Tools -> Gradle\`.
3. Sync Project with Gradle Files.
4. Run on a physical device or emulator running Android 8.0+ (API 26 to 35).
5. Grant Accessibility Service permission in Android Settings when prompted.
`
      );

      zip.file(
        'settings.gradle.kts',
        `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "VØID.AI"
include(":app")
`
      );

      zip.file(
        'build.gradle.kts',
        `plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'VOID_AI_Android_Studio_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="w-full h-full min-h-screen bg-black text-white p-4 md:p-6 flex flex-col gap-5 select-none">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.25)]">
            <Code2 className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-wider font-display">ANDROID STUDIO PROJECT CODE</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700">
                Ready to Build
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              Complete Kotlin & Jetpack Compose Source Tree • Room Database • Accessibility Service
            </p>
          </div>
        </div>

        {/* 1-CLICK ZIP DOWNLOAD BUTTON */}
        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="px-5 py-2.5 rounded-xl bg-cyan-500 text-black font-mono font-bold text-xs hover:bg-cyan-400 active:scale-95 transition-all shadow-[0_0_20px_rgba(0,240,255,0.5)] flex items-center gap-2 disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          <span>{isZipping ? 'PACKAGING ZIP...' : 'DOWNLOAD ANDROID PROJECT (.ZIP)'}</span>
        </button>
      </div>

      {/* CODE STUDIO WORKSPACE */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5 min-h-[550px]">
        
        {/* FILE TREE SELECTOR (4 COLS) */}
        <div className="lg:col-span-4 bg-zinc-950 rounded-2xl border border-white/10 p-3 flex flex-col gap-2">
          <div className="px-3 py-2 flex items-center justify-between text-[11px] font-mono text-zinc-400 border-b border-white/10">
            <span className="flex items-center gap-1.5">
              <Folder className="w-3.5 h-3.5 text-cyan-400" />
              <span>Project Files ({ANDROID_PROJECT_FILES.length})</span>
            </span>
            <span className="text-[10px] text-cyan-400">Kotlin 2.0</span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1 pr-1 max-h-[550px]">
            {ANDROID_PROJECT_FILES.map((file, i) => {
              const fileName = file.path.split('/').pop();
              const isSelected = i === selectedFileIndex;
              return (
                <button
                  key={i}
                  onClick={() => setSelectedFileIndex(i)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono transition-all flex flex-col gap-0.5 ${
                    isSelected
                      ? 'bg-cyan-950/60 text-white border border-cyan-500/50 shadow-[0_0_12px_rgba(0,240,255,0.15)]'
                      : 'text-zinc-400 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2 font-semibold truncate">
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-zinc-500'}`} />
                    <span className="truncate">{fileName}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 truncate pl-5">
                    {file.path}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* CODE PREVIEW & COPY VIEWER (8 COLS) */}
        <div className="lg:col-span-8 bg-zinc-950 rounded-2xl border border-white/10 overflow-hidden flex flex-col">
          
          {/* File Tab Header */}
          <div className="bg-zinc-900/90 px-4 py-2.5 flex items-center justify-between border-b border-white/10 text-xs font-mono">
            <div className="flex items-center gap-2 truncate">
              <span className="text-cyan-400 font-bold">{currentFile.path}</span>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-400 text-[11px] truncate hidden md:inline">
                {currentFile.description}
              </span>
            </div>

            <button
              onClick={handleCopyCode}
              className="px-3 py-1 rounded bg-black/60 hover:bg-white/10 border border-white/15 text-zinc-300 hover:text-white text-[11px] font-mono flex items-center gap-1.5 transition-all active:scale-95 shrink-0"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED!' : 'COPY CODE'}</span>
            </button>
          </div>

          {/* Code Viewer Body */}
          <div className="flex-1 p-4 bg-[#08080a] overflow-auto max-h-[550px]">
            <pre className="font-mono text-xs text-zinc-300 leading-relaxed">
              <code>{currentFile.content}</code>
            </pre>
          </div>

          {/* Footer Info */}
          <div className="px-4 py-2 bg-black border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-zinc-500">
            <span>Language: {currentFile.language.toUpperCase()}</span>
            <span>Lines: {currentFile.content.split('\n').length}</span>
          </div>

        </div>

      </div>

    </div>
  );
};
