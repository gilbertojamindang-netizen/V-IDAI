import React, { useState } from 'react';
import { KeyRound, ShieldCheck, Volume2, Sparkles, CheckCircle2, Lock, Cpu, Play } from 'lucide-react';
import { ApiSettingsState } from '../../types';

interface ApiSettingsScreenViewProps {
  settings: ApiSettingsState;
  onUpdateSettings: (newSettings: Partial<ApiSettingsState>) => void;
  onTestVoice: () => void;
  isTestingVoice: boolean;
}

export const ApiSettingsScreenView: React.FC<ApiSettingsScreenViewProps> = ({
  settings,
  onUpdateSettings,
  onTestVoice,
  isTestingVoice,
}) => {
  const [showKey, setShowKey] = useState(false);
  const [savedNotification, setSavedNotification] = useState(false);

  const handleSaveKey = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNotification(true);
    setTimeout(() => setSavedNotification(false), 2500);
  };

  return (
    <div className="w-full h-full min-h-screen bg-black text-white p-4 md:p-6 flex flex-col gap-5 select-none">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/20 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.2)]">
            <KeyRound className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-wider font-display">API & VOICE ENGINE SETTINGS</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 flex items-center gap-1">
                <Lock className="w-3 h-3" /> Encrypted DataStore Active
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              AES-256 GCM Android KeyStore Encryption • Gemini Live Realtime WebSockets
            </p>
          </div>
        </div>

        {savedNotification && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950 border border-emerald-600 text-emerald-300 text-xs font-mono animate-fadeIn">
            <CheckCircle2 className="w-4 h-4" />
            <span>Vault Updated & Persisted</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* CARD 1: GEMINI API KEY ENCRYPTED VAULT */}
        <div className="bg-zinc-950 p-5 rounded-2xl border border-white/10 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-bold font-mono tracking-wider">Gemini API Key Secure Storage</h2>
            </div>
            <span className="text-[10px] font-mono text-zinc-400">MasterKey::AES256_GCM</span>
          </div>

          <p className="text-xs text-zinc-400 leading-relaxed font-sans">
            In Android production, keys are stored inside <code>EncryptedSharedPreferences</code> backed by the hardware Android KeyStore. If left empty here, VOID will automatically utilize the server-side environment Gemini neural engine.
          </p>

          <form onSubmit={handleSaveKey} className="space-y-3">
            <div>
              <label className="text-[10px] font-mono uppercase text-zinc-400 block mb-1">
                Gemini API Key
              </label>
              <div className="relative">
                <input
                  type={showKey ? 'text' : 'password'}
                  value={settings.apiKey}
                  onChange={(e) => onUpdateSettings({ apiKey: e.target.value })}
                  placeholder="AIzaSy... (or leave blank to use server environment key)"
                  className="w-full bg-black border border-white/20 rounded-xl px-3 py-2 pr-16 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none placeholder:text-zinc-600"
                />
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="absolute right-2 top-2 px-2 py-0.5 rounded text-[10px] font-mono text-zinc-400 hover:text-white bg-zinc-900 border border-white/10"
                >
                  {showKey ? 'HIDE' : 'SHOW'}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[10px] font-mono text-zinc-400">
                Status: {settings.apiKey ? 'Personal Key Stored (Encrypted)' : 'Using Environment AI Studio Proxy'}
              </span>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 text-black font-mono font-bold text-xs rounded-lg hover:bg-cyan-400 active:scale-95 transition-all shadow-[0_0_12px_rgba(0,240,255,0.4)]"
              >
                SAVE TO DATASTORE
              </button>
            </div>
          </form>
        </div>

        {/* CARD 2: GEMINI LIVE MODEL SELECTION */}
        <div className="bg-zinc-950 p-5 rounded-2xl border border-white/10 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-bold font-mono tracking-wider">Gemini Live Voice Model</h2>
            </div>
            <span className="text-[10px] font-mono text-cyan-400">Low-Latency Audio</span>
          </div>

          <div className="space-y-2">
            {[
              {
                id: 'gemini-3.8-flash',
                title: 'Gemini Live 3.8 Flash (Recommended)',
                desc: 'Sub-500ms bidirectional speech-to-speech audio streaming and fast tool calling.',
                badge: 'Live Audio 3.8'
              },
              {
                id: 'gemini-3.1-pro',
                title: 'Gemini Live 3.1 Pro',
                desc: 'Extended contextual reasoning with multimodal screen analysis capabilities.',
                badge: 'Live Pro 3.1'
              },
              {
                id: 'gemini-2.5-flash',
                title: 'Gemini 2.5 Flash',
                desc: 'Balanced reasoning and tactical command execution.',
                badge: 'Fast Fallback'
              },
            ].map((m) => (
              <label
                key={m.id}
                onClick={() => onUpdateSettings({ model: m.id as any })}
                className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  settings.model === m.id
                    ? 'bg-white/10 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.15)]'
                    : 'bg-black/40 border-white/10 hover:border-white/20'
                }`}
              >
                <input
                  type="radio"
                  name="model"
                  checked={settings.model === m.id}
                  onChange={() => {}}
                  className="mt-1 accent-cyan-400"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white font-mono">{m.title}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-zinc-900 border border-white/15 text-zinc-300">
                      {m.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed">{m.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* CARD 3: MALE VOICE PERSONA (CHARON vs FENRIR) */}
        <div className="bg-zinc-950 p-5 rounded-2xl border border-white/10 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-bold font-mono tracking-wider">Male Voice Tone Configuration</h2>
            </div>
            <span className="text-[10px] font-mono text-zinc-400">Deep & Calm Tone</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onUpdateSettings({ voice: 'Charon', pitch: 0.72 })}
              className={`p-3 rounded-xl border text-left transition-all ${
                settings.voice === 'Charon'
                  ? 'bg-cyan-950/40 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'bg-black/40 border-white/10 text-zinc-400 hover:border-white/20'
              }`}
            >
              <div className="text-xs font-bold font-mono text-cyan-300">VOICE: CHARON</div>
              <p className="text-[11px] text-zinc-300 mt-1 leading-relaxed">
                Deep, calm baritone. Highly composed, steady, and tactical.
              </p>
              <span className="text-[9px] font-mono text-zinc-400 block mt-2">PITCH: 0.72 • RATE: 0.95</span>
            </button>

            <button
              onClick={() => onUpdateSettings({ voice: 'Fenrir', pitch: 0.65 })}
              className={`p-3 rounded-xl border text-left transition-all ${
                settings.voice === 'Fenrir'
                  ? 'bg-cyan-950/40 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'bg-black/40 border-white/10 text-zinc-400 hover:border-white/20'
              }`}
            >
              <div className="text-xs font-bold font-mono text-cyan-300">VOICE: FENRIR</div>
              <p className="text-[11px] text-zinc-300 mt-1 leading-relaxed">
                Authoritative, low pitch, military-grade tactical precision.
              </p>
              <span className="text-[9px] font-mono text-zinc-400 block mt-2">PITCH: 0.65 • RATE: 1.00</span>
            </button>
          </div>

          {/* Voice Testing CTA */}
          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">Test Deep Voice Synthesizer:</span>
            <button
              onClick={onTestVoice}
              disabled={isTestingVoice}
              className="px-4 py-2 rounded-lg bg-zinc-900 border border-cyan-400/50 hover:bg-zinc-800 text-xs font-mono font-bold text-cyan-300 hover:text-white flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isTestingVoice ? 'SPEAKING...' : 'HEAR VOICE SAMPLE'}</span>
            </button>
          </div>
        </div>

        {/* CARD 4: FOREGROUND SERVICE LISTENING DAEMON */}
        <div className="bg-zinc-950 p-5 rounded-2xl border border-white/10 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-bold font-mono tracking-wider">Always-Listening Daemon</h2>
            </div>
            <span className="text-[10px] font-mono text-emerald-400">Foreground Service</span>
          </div>

          <p className="text-xs text-zinc-400 leading-relaxed font-sans">
            Controls whether VOID maintains a persistent background wake lock and low-latency audio capture service when minimized or locked.
          </p>

          <div className="flex items-center justify-between p-3 rounded-xl bg-black border border-white/10">
            <div>
              <div className="text-xs font-bold font-mono text-white">Continuous Background Listening</div>
              <div className="text-[10px] font-mono text-zinc-400">Persistent Android Service with WakeLock</div>
            </div>
            <button
              onClick={() => onUpdateSettings({ alwaysListening: !settings.alwaysListening })}
              className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
                settings.alwaysListening ? 'bg-cyan-500' : 'bg-zinc-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-black transition-transform ${
                  settings.alwaysListening ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
