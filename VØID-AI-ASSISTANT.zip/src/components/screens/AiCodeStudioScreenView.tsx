import React, { useState } from 'react';
import { 
  Code2, 
  Terminal, 
  Play, 
  Copy, 
  Check, 
  Download, 
  Sparkles, 
  Send, 
  Monitor, 
  FileCode, 
  RefreshCw, 
  Cpu, 
  CheckCircle2, 
  Sliders
} from 'lucide-react';
import { GeneratedCodeItem, PcCloudState } from '../../types';

interface AiCodeStudioScreenViewProps {
  onGenerateCode: (prompt: string, language: string) => Promise<GeneratedCodeItem | null>;
  isGenerating: boolean;
  history: GeneratedCodeItem[];
  onSendToPc: (code: string, fileName: string) => void;
  onExecuteOnPc: (command: string) => void;
  pcState: PcCloudState;
}

export const AiCodeStudioScreenView: React.FC<AiCodeStudioScreenViewProps> = ({
  onGenerateCode,
  isGenerating,
  history,
  onSendToPc,
  onExecuteOnPc,
  pcState,
}) => {
  const [promptInput, setPromptInput] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('python');
  const [activeCodeItem, setActiveCodeItem] = useState<GeneratedCodeItem>(() => {
    return history[0] || {
      id: 'init_script',
      title: 'Automated System Watchdog',
      language: 'python',
      fileName: 'system_watchdog.py',
      explanation: 'Continuous telemetry watchdog monitoring CPU, RAM, and network socket activity.',
      timestamp: Date.now(),
      code: `# VOID.AI Tactical Developer Subsystem
# File: system_watchdog.py
import sys
import time
import os
import psutil

def monitor_system_telemetry(interval=2):
    print("[VOID] Initializing Tactical System Watchdog daemon...")
    print(f"[VOID] Host PID: {os.getpid()} | Polling interval: {interval}s")
    
    try:
        while True:
            cpu_pct = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory()
            print(f"[TELEMETRY] CPU: {cpu_pct:4.1f}% | RAM: {mem.percent:4.1f}% | Available: {mem.available // (1024*1024)} MB")
            
            if cpu_pct > 85.0:
                print("[ALERT] High CPU threshold exceeded. Notifying VOID Neural Agent.")
                
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\\n[VOID] Watchdog safely terminated by user.")

if __name__ == "__main__":
    monitor_system_telemetry()
`
    };
  });

  const [copied, setCopied] = useState(false);
  const [executionOutput, setExecutionOutput] = useState<string | null>(null);
  const [isRunningSim, setIsRunningSim] = useState(false);

  const handlePromptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim()) return;

    const result = await onGenerateCode(promptInput.trim(), selectedLanguage);
    if (result) {
      setActiveCodeItem(result);
      setExecutionOutput(null);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(activeCodeItem.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([activeCodeItem.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeCodeItem.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleRunInCloudTerminal = () => {
    setIsRunningSim(true);
    setExecutionOutput(null);

    const execCommand = activeCodeItem.language === 'python'
      ? `python3 ${activeCodeItem.fileName}`
      : activeCodeItem.language === 'bash'
      ? `bash ${activeCodeItem.fileName}`
      : `node ${activeCodeItem.fileName}`;

    onExecuteOnPc(execCommand);

    setTimeout(() => {
      setExecutionOutput(`$ ${execCommand}
[VOID CLOUD PC] Spawning process in isolate container...
[STDOUT] Initializing ${activeCodeItem.title}...
[STDOUT] Parsing AST and binding remote sockets...
[STDOUT] Task executed successfully with returncode: 0
[SYS] Memory footprint: 14.2 MB | Runtime: 0.38s`);
      setIsRunningSim(false);
    }, 1200);
  };

  const handleTypeToPc = () => {
    onSendToPc(activeCodeItem.code, activeCodeItem.fileName);
  };

  return (
    <div className="w-full h-full min-h-screen bg-black text-white p-4 md:p-6 flex flex-col gap-5 select-none">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/20 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.2)]">
            <Code2 className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-wider font-display">AI CODING & SCRIPT STUDIO</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700">
                Neural Developer Engine
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              Autonomous Code Generation • Cloud PC Script Injection • Terminal Execution
            </p>
          </div>
        </div>

        {/* CLOUD PC STATUS PILL */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-950 border border-white/10 text-xs font-mono">
          <Monitor className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-zinc-400">Target PC:</span>
          <span className={`font-semibold ${pcState.connected ? 'text-emerald-400' : 'text-zinc-500'}`}>
            {pcState.connected ? `${pcState.ip} (LINKED)` : 'DISCONNECTED'}
          </span>
        </div>
      </div>

      {/* CODE GENERATION PROMPT FORM */}
      <div className="bg-zinc-950 p-4 rounded-2xl border border-white/10 flex flex-col gap-3">
        <form onSubmit={handlePromptSubmit} className="flex flex-col md:flex-row gap-3">
          {/* Language Selector */}
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="bg-black border border-white/20 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:border-cyan-400 focus:outline-none"
          >
            <option value="python">Python 3 (.py)</option>
            <option value="bash">Bash / Shell (.sh)</option>
            <option value="powershell">PowerShell (.ps1)</option>
            <option value="javascript">JavaScript (Node.js)</option>
            <option value="typescript">TypeScript (.ts)</option>
            <option value="kotlin">Kotlin / Compose (.kt)</option>
            <option value="rust">Rust (.rs)</option>
            <option value="sql">SQL / Postgres (.sql)</option>
          </select>

          {/* Prompt Input */}
          <div className="flex-1 relative">
            <input
              type="text"
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              placeholder="Tell VOID what code or script to write (e.g., 'Write an automated file backup script')..."
              className="w-full bg-black border border-white/20 rounded-xl pl-4 pr-12 py-2 text-xs text-white font-mono placeholder:text-zinc-500 focus:border-cyan-400 focus:outline-none"
            />
          </div>

          {/* Generate CTA Button */}
          <button
            type="submit"
            disabled={isGenerating || !promptInput.trim()}
            className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-40 shadow-[0_0_15px_rgba(0,240,255,0.4)] shrink-0"
          >
            {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{isGenerating ? 'SYNTHESIZING...' : 'GENERATE CODE'}</span>
          </button>
        </form>

        {/* Quick Coding Prompt Chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono pt-1">
          <span className="text-zinc-500 uppercase">Templates:</span>
          {[
            { label: 'Automated Backup Daemon', lang: 'python', p: 'Automated directory backup script with timestamp archiving' },
            { label: 'System Telemetry Prober', lang: 'python', p: 'CPU, RAM, and disk utilization prober daemon' },
            { label: 'Remote WebSocket Relay', lang: 'typescript', p: 'Low latency WebSocket client relay for workstation telemetry' },
            { label: 'Cloud PC Setup Script', lang: 'bash', p: 'Bash script to configure headless remote desktop and firewall rules' },
            { label: 'SQLite Memory Purge', lang: 'sql', p: 'SQL vacuum and table indexing query for Room database optimization' }
          ].map((tpl, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setPromptInput(tpl.p);
                setSelectedLanguage(tpl.lang);
              }}
              className="px-2.5 py-1 rounded bg-black/60 hover:bg-white/10 border border-white/10 text-zinc-300 hover:text-white transition-all active:scale-95"
            >
              {tpl.label}
            </button>
          ))}
        </div>
      </div>

      {/* CODE EDITOR & WORKSPACE SPLIT */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* LEFT COLUMN: ACTIVE CODE VIEWER & ACTIONS (8 COLS) */}
        <div className="lg:col-span-8 bg-zinc-950 rounded-2xl border border-white/10 overflow-hidden flex flex-col shadow-2xl">
          
          {/* File Tab Header */}
          <div className="bg-zinc-900/90 px-4 py-2.5 flex items-center justify-between border-b border-white/10 text-xs font-mono">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span className="text-white font-bold">{activeCodeItem.fileName}</span>
              <span className="text-zinc-500">•</span>
              <span className="text-cyan-400 text-[10px] uppercase">{activeCodeItem.language}</span>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="px-2.5 py-1 rounded bg-black/60 hover:bg-white/10 border border-white/15 text-zinc-300 hover:text-white text-[11px] font-mono flex items-center gap-1 transition-all"
                title="Copy code to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'COPIED' : 'COPY'}</span>
              </button>

              <button
                onClick={handleDownload}
                className="px-2.5 py-1 rounded bg-black/60 hover:bg-white/10 border border-white/15 text-zinc-300 hover:text-white text-[11px] font-mono flex items-center gap-1 transition-all"
                title="Download script file"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>SAVE</span>
              </button>
            </div>
          </div>

          {/* Code Body Area with Line Numbers */}
          <div className="flex-1 p-4 bg-[#08080a] overflow-auto max-h-[460px] font-mono text-xs text-zinc-200 leading-relaxed">
            <textarea
              value={activeCodeItem.code}
              onChange={(e) => setActiveCodeItem({ ...activeCodeItem, code: e.target.value })}
              className="w-full h-full min-h-[360px] bg-transparent text-zinc-200 font-mono text-xs resize-none focus:outline-none leading-relaxed"
              spellCheck={false}
            />
          </div>

          {/* CLOUD PC ACTION BAR */}
          <div className="bg-black p-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            <div className="text-[11px] font-mono text-zinc-400">
              <span className="text-cyan-400 font-semibold">{activeCodeItem.code.split('\n').length} lines</span> • {activeCodeItem.code.length} chars
            </div>

            <div className="flex items-center gap-2">
              {/* Type on PC Button */}
              <button
                onClick={handleTypeToPc}
                disabled={!pcState.connected}
                className="px-3.5 py-1.5 rounded-xl bg-zinc-900 border border-white/20 hover:border-cyan-400 text-xs font-mono text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-40"
              >
                <Send className="w-3.5 h-3.5 text-cyan-400" />
                <span>Inject on Cloud PC</span>
              </button>

              {/* Run in Terminal Button */}
              <button
                onClick={handleRunInCloudTerminal}
                disabled={isRunningSim}
                className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-mono font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 shadow-[0_0_12px_rgba(0,240,255,0.3)] disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>{isRunningSim ? 'EXECUTING...' : 'RUN IN CLOUD TERMINAL'}</span>
              </button>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: TERMINAL OUTPUT & SCRIPT HISTORY (4 COLS) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          
          {/* SIMULATED CLOUD TERMINAL OUTPUT */}
          <div className="bg-zinc-950 p-4 rounded-2xl border border-white/10 flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-300 border-b border-white/10 pb-2">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span>Cloud Terminal Output</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold">BASH READY</span>
            </div>

            <div className="bg-[#050505] p-3 rounded-xl border border-white/10 font-mono text-[11px] text-zinc-300 min-h-[160px] max-h-[220px] overflow-y-auto leading-relaxed">
              {executionOutput ? (
                <pre className="text-emerald-400 font-mono whitespace-pre-wrap">
                  {executionOutput}
                </pre>
              ) : (
                <div className="text-zinc-600 space-y-1">
                  <p>$ void-runner --status</p>
                  <p>Cloud PC execution environment ready.</p>
                  <p>Click "RUN IN CLOUD TERMINAL" above to execute the active script remotely.</p>
                </div>
              )}
            </div>
          </div>

          {/* SCRIPT REPOSITORY HISTORY */}
          <div className="bg-zinc-950 p-4 rounded-2xl border border-white/10 flex flex-col gap-2 flex-1">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-300 border-b border-white/10 pb-2">
              <span>Script Repository ({history.length + 1})</span>
              <span className="text-[10px] text-cyan-400">MEMORY CACHE</span>
            </div>

            <div className="space-y-1.5 overflow-y-auto max-h-[200px]">
              {[activeCodeItem, ...history.filter(h => h.id !== activeCodeItem.id)].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveCodeItem(item);
                    setExecutionOutput(null);
                  }}
                  className={`w-full p-2.5 rounded-xl border text-left transition-all flex flex-col gap-0.5 ${
                    activeCodeItem.id === item.id
                      ? 'bg-cyan-950/40 border-cyan-400 text-white'
                      : 'bg-black/40 border-white/5 hover:border-white/15 text-zinc-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-mono font-bold truncate">
                    <span className="truncate">{item.fileName}</span>
                    <span className="text-[9px] uppercase text-cyan-400">{item.language}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 font-sans truncate">
                    {item.explanation || item.title}
                  </span>
                </button>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
