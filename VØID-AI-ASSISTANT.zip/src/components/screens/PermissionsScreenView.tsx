import React from 'react';
import { 
  ShieldCheck, 
  Smartphone, 
  Mic, 
  Camera, 
  Radio, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  ExternalLink 
} from 'lucide-react';

interface PermissionsScreenViewProps {
  accessibilityActive: boolean;
  onToggleAccessibility: () => void;
  foregroundActive: boolean;
  onToggleForeground: () => void;
}

export const PermissionsScreenView: React.FC<PermissionsScreenViewProps> = ({
  accessibilityActive,
  onToggleAccessibility,
  foregroundActive,
  onToggleForeground,
}) => {
  return (
    <div className="w-full h-full min-h-screen bg-black text-white p-4 md:p-6 flex flex-col gap-5 select-none">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/20 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.2)]">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-wider font-display">SYSTEM PERMISSIONS & DAEMONS</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700">
                Android 15 Architecture
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              Accessibility Service Bindings • Low-Power Audio WakeLocks • Hardware Access
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* PERMISSION 1: ACCESSIBILITY SERVICE (CRITICAL) */}
        <div className="bg-zinc-950 p-5 rounded-2xl border border-white/15 flex flex-col justify-between gap-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold font-mono tracking-wider">Android Accessibility Service</h3>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                accessibilityActive 
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700' 
                  : 'bg-amber-950 text-amber-300 border-amber-700'
              }`}>
                {accessibilityActive ? 'GRANTED & BOUND' : 'ACTION REQUIRED'}
              </span>
            </div>

            <p className="text-xs text-zinc-400 leading-relaxed font-sans mb-3">
              Required for VOID to autonomously open apps, click UI buttons, scroll feeds, inject text into inputs, and inspect on-screen nodes in real-time.
            </p>

            <div className="p-3 bg-black/60 rounded-xl border border-white/10 text-[11px] font-mono text-zinc-300 space-y-1">
              <div className="text-zinc-500 font-bold uppercase">// Android System Manifest:</div>
              <div><code>android.permission.BIND_ACCESSIBILITY_SERVICE</code></div>
              <div className="text-emerald-400">Flags: canRetrieveWindowContent | canPerformGestures</div>
            </div>
          </div>

          <button
            onClick={onToggleAccessibility}
            className={`w-full py-2.5 rounded-xl font-mono text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-2 ${
              accessibilityActive
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700 hover:bg-emerald-900'
                : 'bg-cyan-500 text-black hover:bg-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.4)]'
            }`}
          >
            {accessibilityActive ? <CheckCircle2 className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
            <span>{accessibilityActive ? 'SERVICE RUNNING' : 'OPEN ACCESSIBILITY SETTINGS'}</span>
          </button>
        </div>

        {/* PERMISSION 2: FOREGROUND SERVICE (ALWAYS-LISTENING) */}
        <div className="bg-zinc-950 p-5 rounded-2xl border border-white/15 flex flex-col justify-between gap-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <Radio className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold font-mono tracking-wider">Foreground Voice Daemon</h3>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                foregroundActive 
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700' 
                  : 'bg-zinc-900 text-zinc-400 border-zinc-700'
              }`}>
                {foregroundActive ? 'ACTIVE DAEMON' : 'STANDBY'}
              </span>
            </div>

            <p className="text-xs text-zinc-400 leading-relaxed font-sans mb-3">
              Runs an ongoing notification service with a partial WakeLock so VOID can remain in continuous listening mode even when your phone is locked or other apps are running.
            </p>

            <div className="p-3 bg-black/60 rounded-xl border border-white/10 text-[11px] font-mono text-zinc-300 space-y-1">
              <div className="text-zinc-500 font-bold uppercase">// Service Type:</div>
              <div><code>FOREGROUND_SERVICE_MICROPHONE</code></div>
              <div className="text-cyan-400">Notification: Persistent Tactical Audio Daemon</div>
            </div>
          </div>

          <button
            onClick={onToggleForeground}
            className={`w-full py-2.5 rounded-xl font-mono text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-2 ${
              foregroundActive
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700 hover:bg-emerald-900'
                : 'bg-white/10 text-white hover:bg-white/20 border border-white/20'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{foregroundActive ? 'DAEMON ONLINE (RUNNING)' : 'ENABLE BACKGROUND DAEMON'}</span>
          </button>
        </div>

        {/* PERMISSION 3: MICROPHONE & AUDIO RECORDING */}
        <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center border border-white/10">
              <Mic className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="text-xs font-bold font-mono text-white">Record Audio / Microphone</div>
              <div className="text-[10px] font-mono text-zinc-400">android.permission.RECORD_AUDIO</div>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
            GRANTED
          </span>
        </div>

        {/* PERMISSION 4: CAMERA & QR PROCESSOR */}
        <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center border border-white/10">
              <Camera className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="text-xs font-bold font-mono text-white">Camera & QR Code Reader</div>
              <div className="text-[10px] font-mono text-zinc-400">android.permission.CAMERA</div>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
            GRANTED
          </span>
        </div>

      </div>

    </div>
  );
};
