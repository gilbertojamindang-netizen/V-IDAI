import React from 'react';
import { Menu, Mic, MicOff, Volume2, Sparkles, Terminal, Smartphone, Monitor } from 'lucide-react';
import { CyberpunkAvatar } from '../CyberpunkAvatar';
import { AudioWaveform } from '../AudioWaveform';
import { TacticalSystemMonitor } from '../TacticalSystemMonitor';
import { PWAInstallButton } from '../PWAInstallButton';

interface HomeScreenViewProps {
  onOpenDrawer: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleMic: () => void;
  transcript: string;
  assistantReply: string;
  isProcessing: boolean;
  onQuickCommand: (cmd: string) => void;
  voicePersona: 'Charon' | 'Fenrir';
  connectedToPc: boolean;
  accessibilityActive: boolean;
  avatarImageUrl?: string;
  onChangeAvatarClick?: () => void;
}

export const HomeScreenView: React.FC<HomeScreenViewProps> = ({
  onOpenDrawer,
  isListening,
  isSpeaking,
  onToggleMic,
  transcript,
  assistantReply,
  isProcessing,
  onQuickCommand,
  voicePersona,
  connectedToPc,
  accessibilityActive,
  avatarImageUrl,
  onChangeAvatarClick,
}) => {
  return (
    <div className="relative w-full h-full min-h-screen bg-[#000000] text-white flex flex-col justify-between overflow-x-hidden select-none">
      
      {/* Subtle Tactical Ambient Grid Lines */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.03]" 
        style={{
          backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      />

      {/* TOP BAR & STATUS ZONE */}
      <header className="relative z-20 flex items-center justify-between px-4 sm:px-6 pt-6 pb-2 gap-2">
        {/* Left: Navigation Drawer Trigger */}
        <button
          onClick={onOpenDrawer}
          className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/10 text-white hover:border-cyan-400/50 hover:bg-zinc-900 transition-all shadow-[0_0_10px_rgba(0,0,0,0.5)] active:scale-95 cursor-pointer shrink-0"
          aria-label="Open Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Center: TOP TEXT specification with VØID.AI App Logo */}
        <div className="flex items-center gap-3">
          <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden border border-cyan-400/60 shadow-[0_0_15px_rgba(6,182,212,0.35)] shrink-0 group">
            <img 
              src="/logo.jpg" 
              alt="VØID.AI App Logo" 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
          </div>
          <div className="flex flex-col items-start sm:items-center">
            <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold tracking-[0.2em] text-white font-display glow-white">
              VØID.AI
            </h1>
            <div className="flex items-center gap-2 mt-0.5 text-[9px] sm:text-[10px] md:text-xs font-mono tracking-widest text-zinc-400">
              <span className="hidden sm:inline">VOICE ASSISTANT</span>
              <span className="hidden sm:inline text-zinc-600 font-bold">•</span>
              <span className="flex items-center gap-1 text-cyan-400 font-bold glow-cyan">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping inline-block" />
                ONLINE
              </span>
            </div>
          </div>
        </div>

        {/* Right: PWA Install trigger + Voice Persona pill */}
        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton variant="compact" />
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-950 border border-white/10 text-[10px] font-mono text-zinc-400">
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-white font-semibold">{voicePersona}</span>
          </div>
        </div>
      </header>

      {/* CENTER ZONE: VISUAL & HERO PROMPT */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-2 text-center max-w-xl mx-auto w-full">
        
        {/* Status Indicators Strip */}
        <div className="flex items-center gap-4 mb-2 text-[10px] font-mono tracking-wider text-zinc-400">
          <div className="flex items-center gap-1.5">
            <Smartphone className={`w-3 h-3 ${accessibilityActive ? 'text-emerald-400' : 'text-zinc-400'}`} />
            <span>ACCESSIBILITY: {accessibilityActive ? 'ACTIVE' : 'READY'}</span>
          </div>
          <span>|</span>
          <div className="flex items-center gap-1.5">
            <Monitor className={`w-3 h-3 ${connectedToPc ? 'text-cyan-400' : 'text-zinc-400'}`} />
            <span>PC CLOUD: {connectedToPc ? 'LINKED' : 'STANDBY'}</span>
          </div>
        </div>

        {/* Real-time Cyberpunk Tactical System Monitor (CPU, RAM, Battery) */}
        <TacticalSystemMonitor />

        {/* Center Visual: Mysterious Male AI Figure with Glowing Eyes & Glowing White Concentric Rings */}
        <div className="my-2">
          <CyberpunkAvatar
            isListening={isListening}
            isSpeaking={isSpeaking}
            size={260}
            imageUrl={avatarImageUrl}
            onChangeClick={onChangeAvatarClick}
          />
        </div>

        {/* BELOW THE VISUAL: Large text saying "I'M VØID. HOW CAN I HELP YOU?" */}
        <div className="mt-4 mb-2 space-y-1">
          <h2 className="text-xl md:text-2xl font-extrabold tracking-wide text-white font-display">
            I'M VØID.
          </h2>
          <p className="text-lg md:text-xl font-bold tracking-normal text-zinc-300 font-display">
            HOW CAN I HELP YOU?
          </p>
        </div>

        {/* LIVE TRANSCRIPTION / ASSISTANT REPLY CARD */}
        {(transcript || assistantReply || isProcessing) && (
          <div className="w-full max-w-md mx-auto mt-2 px-4 py-3 rounded-xl bg-zinc-950/90 border border-white/15 backdrop-blur-md shadow-[0_0_20px_rgba(0,0,0,0.8)] text-left animate-fadeIn">
            {transcript && (
              <div className="mb-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400">You</span>
                <p className="text-sm text-zinc-200 font-medium">"{transcript}"</p>
              </div>
            )}
            {isProcessing && (
              <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 animate-pulse">
                <Terminal className="w-3.5 h-3.5" />
                <span>VOID neural processing...</span>
              </div>
            )}
            {assistantReply && !isProcessing && (
              <div className="border-t border-white/10 pt-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400">VOID [{voicePersona}]</span>
                <p className="text-sm text-white font-semibold leading-relaxed">{assistantReply}</p>
              </div>
            )}
          </div>
        )}

        {/* QUICK VOICE ACTION PROMPTS */}
        <div className="w-full max-w-md mt-4 flex flex-wrap items-center justify-center gap-1.5">
          {[
            'start work',
            'Code a Python Script',
            'stealth mode',
            'Open Instagram',
            'Move PC mouse left',
            'Take phone screenshot',
          ].map((cmd, i) => (
            <button
              key={i}
              onClick={() => onQuickCommand(cmd)}
              className="px-2.5 py-1 rounded-full bg-zinc-950 border border-white/10 hover:border-cyan-400/50 hover:bg-zinc-900 text-[11px] font-mono text-zinc-300 hover:text-white transition-all active:scale-95"
            >
              "{cmd}"
            </button>
          ))}
        </div>
      </main>

      {/* BOTTOM ZONE: AUDIO WAVEFORM & LARGE CIRCULAR MICROPHONE BUTTON */}
      <footer className="relative z-20 flex flex-col items-center pb-8 pt-2 px-6 gap-3">
        {/* Audio Waveform Visualizer */}
        <div className="w-full max-w-md">
          <AudioWaveform
            isActive={isListening}
            isSpeaking={isSpeaking}
            barCount={36}
          />
        </div>

        {/* Large Circular Microphone Button */}
        <div className="relative flex items-center justify-center">
          {/* Animated concentric pulse ripples when listening */}
          {isListening && (
            <>
              <div className="absolute w-28 h-28 rounded-full border border-cyan-400/40 animate-ping pointer-events-none" />
              <div className="absolute w-24 h-24 rounded-full bg-cyan-500/10 animate-pulse pointer-events-none" />
            </>
          )}

          <button
            onClick={onToggleMic}
            className={`relative z-10 w-20 h-20 rounded-full flex flex-col items-center justify-center transition-all duration-300 active:scale-95 shadow-2xl ${
              isListening
                ? 'bg-white text-black border-2 border-cyan-400 shadow-[0_0_35px_rgba(0,240,255,0.7)] scale-105'
                : 'bg-zinc-950 text-white border-2 border-white/30 hover:border-white shadow-[0_0_20px_rgba(255,255,255,0.15)] hover:shadow-[0_0_25px_rgba(255,255,255,0.3)]'
            }`}
            aria-label={isListening ? 'Stop listening' : 'Start voice assistant'}
          >
            {isListening ? (
              <Mic className="w-8 h-8 text-cyan-600 animate-pulse" />
            ) : (
              <Mic className="w-8 h-8 text-white" />
            )}
            <span className="text-[9px] font-mono uppercase tracking-wider mt-0.5 font-bold">
              {isListening ? 'REC' : 'MIC'}
            </span>
          </button>
        </div>

        <div className="text-[10px] font-mono text-zinc-400 tracking-wider">
          {isListening ? 'LISTENING MODE ACTIVE // TAP TO PAUSE' : 'TAP MIC TO ACTIVATE NEURAL LINK'}
        </div>
      </footer>
    </div>
  );
};
