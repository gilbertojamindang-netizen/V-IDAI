import React, { useState, useRef } from 'react';
import { 
  Monitor, 
  Wifi, 
  WifiOff, 
  MousePointer2, 
  Keyboard, 
  Terminal, 
  Play, 
  RotateCcw, 
  Send, 
  Sliders, 
  Cpu, 
  Activity,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Maximize2
} from 'lucide-react';
import { PcCloudState } from '../../types';

interface PcCloudScreenViewProps {
  pcState: PcCloudState;
  onConnectToggle: () => void;
  onMoveCursor: (dx: number, dy: number) => void;
  onClickCursor: () => void;
  onTypeText: (text: string) => void;
  onShortcut: (key: string) => void;
}

export const PcCloudScreenView: React.FC<PcCloudScreenViewProps> = ({
  pcState,
  onConnectToggle,
  onMoveCursor,
  onClickCursor,
  onTypeText,
  onShortcut,
}) => {
  const [ipInput, setIpInput] = useState(pcState.ip);
  const [codeInput, setCodeInput] = useState(pcState.connectionCode);
  const [textToType, setTextToType] = useState('');
  const desktopRef = useRef<HTMLDivElement>(null);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (textToType.trim()) {
      onTypeText(textToType.trim());
      setTextToType('');
    }
  };

  // Handle direct touch/click on the virtual desktop to position cursor
  const handleDesktopClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!desktopRef.current || !pcState.connected) return;
    const rect = desktopRef.current.getBoundingClientRect();
    const x = Math.round(e.clientX - rect.left);
    const y = Math.round(e.clientY - rect.top);
    // Move relative to current
    onMoveCursor(x - pcState.cursor.x, y - pcState.cursor.y);
  };

  return (
    <div className="w-full h-full min-h-screen bg-black text-white p-4 md:p-6 flex flex-col gap-5 select-none">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/20 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.2)]">
            <Monitor className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-wider font-display">PC CLOUD CONTROL</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700">
                QuickTrip Remote Engine
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              Voice-to-Desktop Remote Automation • Direct Mouse & Keystroke Injection
            </p>
          </div>
        </div>

        {/* CONNECTION TOGGLE STATUS */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-950 border border-white/10 text-xs font-mono">
            {pcState.connected ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400 font-semibold">CONNECTED</span>
                <span className="text-zinc-500">|</span>
                <span className="text-zinc-300">{pcState.latencyMs}ms</span>
                <span className="text-zinc-500">|</span>
                <span className="text-cyan-400">{pcState.fps} FPS</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-zinc-600" />
                <span className="text-zinc-400">DISCONNECTED</span>
              </>
            )}
          </div>

          <button
            onClick={onConnectToggle}
            className={`px-4 py-2 rounded-lg text-xs font-bold font-mono tracking-wider transition-all active:scale-95 flex items-center gap-2 ${
              pcState.connected
                ? 'bg-rose-950/80 text-rose-300 border border-rose-800 hover:bg-rose-900'
                : 'bg-cyan-500 text-black hover:bg-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.4)]'
            }`}
          >
            {pcState.connected ? <WifiOff className="w-4 h-4" /> : <Wifi className="w-4 h-4" />}
            <span>{pcState.connected ? 'TERMINATE LINK' : 'CONNECT TO PC'}</span>
          </button>
        </div>
      </div>

      {/* IP & CONNECTION CODE CONFIGURATION ROW */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-zinc-950 p-3 rounded-xl border border-white/10 text-xs font-mono">
        <div>
          <label className="text-zinc-400 block mb-1 text-[10px] uppercase">Target PC Host / IP</label>
          <input
            type="text"
            value={ipInput}
            onChange={(e) => setIpInput(e.target.value)}
            disabled={pcState.connected}
            className="w-full bg-black border border-white/15 rounded-lg px-3 py-1.5 text-white font-mono focus:border-cyan-400 focus:outline-none"
            placeholder="192.168.1.188:8080"
          />
        </div>

        <div>
          <label className="text-zinc-400 block mb-1 text-[10px] uppercase">Connection Code (QuickTrip)</label>
          <input
            type="text"
            value={codeInput}
            onChange={(e) => setCodeInput(e.target.value)}
            disabled={pcState.connected}
            className="w-full bg-black border border-white/15 rounded-lg px-3 py-1.5 text-white font-mono focus:border-cyan-400 focus:outline-none"
            placeholder="VOID-8821"
          />
        </div>

        <div className="flex flex-col justify-end">
          <div className="text-[11px] text-zinc-400 flex items-center gap-2 py-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>Voice Voice Synthesizer: Say "VOID, move mouse right" or "VOID, type on PC"</span>
          </div>
        </div>
      </div>

      {/* MAIN VIEWPORT: VIRTUAL PC MONITOR STREAM */}
      <div className="flex-1 flex flex-col lg:flex-row gap-4">
        
        {/* VIRTUAL PC DISPLAY CANVAS */}
        <div className="flex-1 flex flex-col bg-zinc-950 rounded-2xl border border-white/15 overflow-hidden shadow-2xl">
          
          {/* Virtual Window Header */}
          <div className="bg-zinc-900 px-4 py-2.5 flex items-center justify-between border-b border-white/10 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              <span className="ml-2 text-zinc-300 font-semibold">{pcState.clientName} :~ {pcState.activeWindow}</span>
            </div>
            <div className="flex items-center gap-3 text-[10px] text-zinc-400">
              <span>RES: 1920x1080 (SCALED)</span>
              <span>CURSOR: X:{pcState.cursor.x} Y:{pcState.cursor.y}</span>
            </div>
          </div>

          {/* Screen Content Area */}
          <div
            ref={desktopRef}
            onClick={handleDesktopClick}
            className="relative flex-1 min-h-[340px] md:min-h-[420px] bg-[#0c0d10] p-4 font-mono text-xs overflow-hidden cursor-crosshair select-none"
          >
            {/* Background Simulated Desktop Wallpaper & Grid */}
            <div 
              className="absolute inset-0 opacity-10 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(circle, #00f0ff 1px, transparent 1px)',
                backgroundSize: '24px 24px'
              }}
            />

            {/* Desktop Windows Simulation */}
            <div className="relative z-0 grid grid-cols-1 md:grid-cols-2 gap-4 h-full pointer-events-none">
              
              {/* Window 1: Code Workspace */}
              <div className="bg-[#12141a]/95 rounded-xl border border-cyan-500/30 p-3 shadow-lg flex flex-col justify-between">
                <div>
                  <div className="text-[10px] text-cyan-400 border-b border-white/10 pb-1 mb-2 flex items-center justify-between">
                    <span>main.py — VOID_Daemon</span>
                    <span className="text-zinc-500">UTF-8</span>
                  </div>
                  <pre className="text-[11px] text-zinc-300 space-y-0.5 leading-relaxed overflow-x-hidden">
                    <span className="text-purple-400">import</span> sys, socket, pyautogui<br/>
                    <span className="text-purple-400">class</span> <span className="text-cyan-300">VoidRemoteEngine</span>:<br/>
                    &nbsp;&nbsp;<span className="text-purple-400">def</span> <span className="text-blue-300">execute_voice_action</span>(cmd):<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;pyautogui.moveTo(cmd.x, cmd.y, duration=0.15)<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;pyautogui.typewrite(cmd.text)<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-emerald-400"># Listening on port 8080 (Encrypted)</span><br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-zinc-400">return</span> Status.OK
                  </pre>
                </div>
                <div className="text-[10px] text-emerald-400 font-mono pt-2 border-t border-white/10">
                  READY FOR VOICE INJECTION
                </div>
              </div>

              {/* Window 2: Live Shell / Bash Output */}
              <div className="bg-[#08080a]/95 rounded-xl border border-white/15 p-3 shadow-lg flex flex-col justify-between">
                <div>
                  <div className="text-[10px] text-zinc-400 border-b border-white/10 pb-1 mb-2 flex items-center justify-between">
                    <span>bash - 80x24</span>
                    <span className="text-emerald-400">ACTIVE</span>
                  </div>
                  <div className="space-y-1 text-[11px] text-zinc-300">
                    <p className="text-zinc-500">$ void-agent --listen 8080</p>
                    <p className="text-cyan-400">[QUICKTRIP] Remote link established from mobile.</p>
                    <p className="text-zinc-400">[INPUT_RELAY] Virtual mouse & keyboard bound.</p>
                    {pcState.terminalLogs.slice(-4).map((log, i) => (
                      <p key={i} className="text-emerald-300 font-mono">
                        &gt; {log}
                      </p>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-cyan-400 text-xs">
                  <span>void@workstation:~$</span>
                  <span className="w-2 h-4 bg-cyan-400 animate-pulse" />
                </div>
              </div>

            </div>

            {/* LIVE MOVING MOUSE CURSOR */}
            <div
              className="absolute z-20 pointer-events-none transition-all duration-150 ease-out flex items-center gap-1"
              style={{
                left: `${pcState.cursor.x}px`,
                top: `${pcState.cursor.y}px`,
              }}
            >
              <MousePointer2 
                className="w-5 h-5 text-white drop-shadow-[0_0_8px_rgba(0,240,255,0.9)] fill-cyan-400" 
              />
              <span className="text-[9px] font-mono bg-black/90 px-1 py-0.5 rounded text-cyan-300 border border-cyan-800">
                X:{pcState.cursor.x}
              </span>
            </div>

            {/* Overlay if Disconnected */}
            {!pcState.connected && (
              <div className="absolute inset-0 bg-black/85 backdrop-blur-sm z-30 flex flex-col items-center justify-center gap-3">
                <WifiOff className="w-10 h-10 text-zinc-600 animate-pulse" />
                <h3 className="text-sm font-bold font-mono tracking-wider text-zinc-300">
                  PC CLOUD STANDBY // NO LINK
                </h3>
                <p className="text-xs text-zinc-500 font-mono max-w-sm text-center">
                  Click "CONNECT TO PC" above to establish low-latency QuickTrip remote control stream.
                </p>
                <button
                  onClick={onConnectToggle}
                  className="mt-2 px-4 py-2 rounded-lg bg-cyan-500 text-black font-mono text-xs font-bold hover:bg-cyan-400 transition-all shadow-[0_0_15px_rgba(0,240,255,0.4)]"
                >
                  ESTABLISH REMOTE CONNECTION
                </button>
              </div>
            )}
          </div>
        </div>

        {/* SIDEBAR: CONTROLS, SHORTCUTS & VIRTUAL TRACKPAD */}
        <div className="w-full lg:w-80 flex flex-col gap-4">
          
          {/* VIRTUAL TRACKPAD & CURSOR D-PAD */}
          <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-300">
              <span className="flex items-center gap-2">
                <MousePointer2 className="w-4 h-4 text-cyan-400" />
                <span>Cursor D-Pad & Click</span>
              </span>
              <span className="text-[10px] text-zinc-500">VOICE: "Move mouse left"</span>
            </div>

            {/* D-Pad Buttons */}
            <div className="grid grid-cols-3 gap-2 w-48 mx-auto my-1">
              <div />
              <button
                onClick={() => onMoveCursor(0, -60)}
                disabled={!pcState.connected}
                className="p-3 bg-zinc-900 border border-white/10 rounded-xl hover:bg-white/10 active:scale-90 flex items-center justify-center transition-all disabled:opacity-40"
              >
                <ArrowUp className="w-4 h-4 text-cyan-300" />
              </button>
              <div />
              
              <button
                onClick={() => onMoveCursor(-80, 0)}
                disabled={!pcState.connected}
                className="p-3 bg-zinc-900 border border-white/10 rounded-xl hover:bg-white/10 active:scale-90 flex items-center justify-center transition-all disabled:opacity-40"
              >
                <ArrowLeft className="w-4 h-4 text-cyan-300" />
              </button>
              
              <button
                onClick={onClickCursor}
                disabled={!pcState.connected}
                className="p-3 bg-cyan-500/20 border border-cyan-400 rounded-xl text-xs font-bold font-mono text-cyan-300 hover:bg-cyan-500/30 active:scale-90 flex items-center justify-center transition-all disabled:opacity-40 shadow-[0_0_10px_rgba(0,240,255,0.2)]"
              >
                CLICK
              </button>
              
              <button
                onClick={() => onMoveCursor(80, 0)}
                disabled={!pcState.connected}
                className="p-3 bg-zinc-900 border border-white/10 rounded-xl hover:bg-white/10 active:scale-90 flex items-center justify-center transition-all disabled:opacity-40"
              >
                <ArrowRight className="w-4 h-4 text-cyan-300" />
              </button>
              
              <div />
              <button
                onClick={() => onMoveCursor(0, 60)}
                disabled={!pcState.connected}
                className="p-3 bg-zinc-900 border border-white/10 rounded-xl hover:bg-white/10 active:scale-90 flex items-center justify-center transition-all disabled:opacity-40"
              >
                <ArrowDown className="w-4 h-4 text-cyan-300" />
              </button>
              <div />
            </div>

            <div className="grid grid-cols-2 gap-2 mt-1">
              <button
                onClick={onClickCursor}
                disabled={!pcState.connected}
                className="py-2 bg-zinc-900 border border-white/15 rounded-lg text-xs font-mono text-zinc-300 hover:text-white hover:bg-white/10 active:scale-95 disabled:opacity-40"
              >
                LEFT CLICK
              </button>
              <button
                onClick={() => onShortcut('RIGHT_CLICK')}
                disabled={!pcState.connected}
                className="py-2 bg-zinc-900 border border-white/15 rounded-lg text-xs font-mono text-zinc-300 hover:text-white hover:bg-white/10 active:scale-95 disabled:opacity-40"
              >
                RIGHT CLICK
              </button>
            </div>
          </div>

          {/* REMOTE KEYBOARD INJECTION */}
          <div className="bg-zinc-950 p-4 rounded-xl border border-white/10 flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-300">
              <span className="flex items-center gap-2">
                <Keyboard className="w-4 h-4 text-cyan-400" />
                <span>Remote Typing & Shortcuts</span>
              </span>
            </div>

            <form onSubmit={handleSendText} className="flex gap-2">
              <input
                type="text"
                value={textToType}
                onChange={(e) => setTextToType(e.target.value)}
                placeholder="Text to type on PC..."
                disabled={!pcState.connected}
                className="flex-1 bg-black border border-white/15 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none disabled:opacity-40"
              />
              <button
                type="submit"
                disabled={!pcState.connected || !textToType.trim()}
                className="px-3 py-1.5 bg-cyan-500 text-black font-mono text-xs font-bold rounded-lg hover:bg-cyan-400 transition-all disabled:opacity-40 active:scale-95"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Quick Macro Shortcut Chips */}
            <div className="grid grid-cols-3 gap-1.5 text-[11px] font-mono">
              {['Ctrl + C', 'Ctrl + V', 'Alt + Tab', 'Win / Super', 'Enter', 'Esc'].map((sc, i) => (
                <button
                  key={i}
                  onClick={() => onShortcut(sc)}
                  disabled={!pcState.connected}
                  className="py-1.5 px-2 bg-zinc-900 hover:bg-white/10 border border-white/10 rounded text-zinc-300 hover:text-white transition-all disabled:opacity-40 active:scale-95"
                >
                  {sc}
                </button>
              ))}
            </div>
          </div>

          {/* VOICE MACROS HELPER */}
          <div className="bg-zinc-950 p-3 rounded-xl border border-white/10 text-[11px] font-mono text-zinc-400 space-y-1">
            <span className="text-cyan-400 font-bold block mb-1">VOICE COMMAND EXAMPLES:</span>
            <p className="text-zinc-300">• "VOID, type this on my PC: npm test"</p>
            <p className="text-zinc-300">• "VOID, move the mouse to the left"</p>
            <p className="text-zinc-300">• "VOID, click mouse on PC"</p>
            <p className="text-zinc-300">• "VOID, press Alt Tab"</p>
          </div>

        </div>

      </div>

    </div>
  );
};
