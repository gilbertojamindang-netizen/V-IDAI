import React from 'react';
import { Camera, Image as ImageIcon } from 'lucide-react';

interface CyberpunkAvatarProps {
  isListening: boolean;
  isSpeaking: boolean;
  size?: number;
  imageUrl?: string;
  onChangeClick?: () => void;
}

export const CyberpunkAvatar: React.FC<CyberpunkAvatarProps> = ({
  isListening,
  isSpeaking,
  size = 280,
  imageUrl = '/src/assets/images/void_hooded_cyborg_1793161662943.jpg',
  onChangeClick,
}) => {
  return (
    <div
      className="relative flex items-center justify-center select-none group"
      style={{ width: size, height: size }}
    >
      {/* Outer ambient glow */}
      <div
        className={`absolute inset-0 rounded-full transition-opacity duration-700 pointer-events-none ${
          isSpeaking
            ? 'opacity-85 bg-cyan-500/20 blur-2xl'
            : isListening
            ? 'opacity-75 bg-white/15 blur-xl'
            : 'opacity-35 bg-cyan-950/25 blur-lg'
        }`}
      />

      {/* Outer Concentric Glowing Rings (SVG Layer) */}
      <svg
        className={`absolute inset-0 w-full h-full pointer-events-none ${
          isListening ? 'animate-ring-rotate-cw' : 'animate-ring-rotate-cw'
        }`}
        viewBox="0 0 300 300"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outermost Ring 1 */}
        <circle
          cx="150"
          cy="150"
          r="142"
          stroke="#FFFFFF"
          strokeWidth="1.2"
          strokeOpacity="0.85"
          className="transition-all duration-300"
          style={{ filter: 'drop-shadow(0 0 6px rgba(255, 255, 255, 0.7))' }}
        />

        {/* Tactical Tick Marks on Ring 1 */}
        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => {
          const rad = (angle * Math.PI) / 180;
          const x1 = 150 + 138 * Math.cos(rad);
          const y1 = 150 + 138 * Math.sin(rad);
          const x2 = 150 + 146 * Math.cos(rad);
          const y2 = 150 + 146 * Math.sin(rad);
          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#00F0FF"
              strokeWidth="2"
              strokeOpacity="0.9"
            />
          );
        })}

        {/* Ring 2 (Dashed Tactical Orbit) */}
        <circle
          cx="150"
          cy="150"
          r="126"
          stroke="#00F0FF"
          strokeWidth="1.2"
          strokeDasharray="6 14"
          strokeOpacity="0.6"
          style={{ filter: 'drop-shadow(0 0 4px rgba(0, 240, 255, 0.5))' }}
        />

        {/* Ring 3 (Inner Glowing White Orbit) */}
        <circle
          cx="150"
          cy="150"
          r="110"
          stroke="#FFFFFF"
          strokeWidth="1"
          strokeOpacity="0.75"
          style={{ filter: 'drop-shadow(0 0 5px rgba(255, 255, 255, 0.6))' }}
        />

        {/* Ring 4 (Fine Sub-Orbital Ring) */}
        <circle
          cx="150"
          cy="150"
          r="98"
          stroke="#00F0FF"
          strokeWidth="0.8"
          strokeDasharray="2 8"
          strokeOpacity="0.4"
        />
      </svg>

      {/* Reverse counter-rotating accent ring */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none animate-ring-rotate-ccw"
        viewBox="0 0 300 300"
        fill="none"
      >
        <circle
          cx="150"
          cy="150"
          r="134"
          stroke="rgba(255, 255, 255, 0.4)"
          strokeWidth="1"
          strokeDasharray="18 42"
        />
      </svg>

      {/* Central Portrait Container */}
      <div
        className={`relative z-10 w-[184px] h-[184px] rounded-full overflow-hidden border border-white/30 bg-black flex items-center justify-center transition-all duration-500 shadow-2xl ${
          isSpeaking
            ? 'scale-105 border-cyan-400 shadow-[0_0_35px_rgba(0,240,255,0.4)]'
            : isListening
            ? 'scale-102 border-white shadow-[0_0_30px_rgba(255,255,255,0.35)]'
            : 'border-white/20 shadow-[0_0_20px_rgba(0,0,0,0.8)]'
        }`}
      >
        {/* Tactical AI Portrait Image */}
        <img
          src={imageUrl}
          alt="VOID.AI Male Tactical Figure"
          className="w-full h-full object-cover object-center filter contrast-110 brightness-105"
          referrerPolicy="no-referrer"
        />

        {/* Subtly animated overlay lens when active */}
        <div
          className={`absolute inset-0 transition-opacity duration-300 pointer-events-none ${
            isSpeaking
              ? 'opacity-25 bg-gradient-to-t from-cyan-500/40 via-transparent to-transparent'
              : isListening
              ? 'opacity-20 bg-gradient-to-b from-white/20 via-transparent to-cyan-500/20'
              : 'opacity-0'
          }`}
        />

        {/* High-tech ocular focal indicator when speaking */}
        {isSpeaking && (
          <div className="absolute top-[32%] left-[45%] w-3 h-1 bg-cyan-300/80 rounded-full blur-[1px] animate-pulse" />
        )}

        {/* Hover / Tap Overlay to Change or Upload Custom Image */}
        {onChangeClick && (
          <button
            onClick={onChangeClick}
            type="button"
            className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col items-center justify-center gap-1 z-30 cursor-pointer"
            title="Change or Upload Image"
          >
            <Camera className="w-6 h-6 text-cyan-300 drop-shadow-md" />
            <span className="text-[10px] font-mono text-white tracking-wider uppercase font-bold bg-black/80 px-2 py-0.5 rounded border border-white/20">
              Change Image
            </span>
          </button>
        )}
      </div>

      {/* Micro Telemetry Coordinate Overlay */}
      <div className="absolute bottom-1 right-2 text-[8px] font-mono tracking-widest text-white/40 uppercase pointer-events-none">
        00:45:12 // SEC_TGT
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono tracking-widest text-cyan-400/50 uppercase pointer-events-none">
        AI_UNIT_07
      </div>

      {/* Floating Change Image Badge */}
      {onChangeClick && (
        <button
          onClick={onChangeClick}
          type="button"
          className="absolute -bottom-2 z-20 px-2.5 py-1 rounded-full bg-zinc-950/90 border border-white/20 hover:border-cyan-400 text-[10px] font-mono text-zinc-300 hover:text-white flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
        >
          <ImageIcon className="w-3 h-3 text-cyan-400" />
          <span>Change / Upload Figure</span>
        </button>
      )}
    </div>
  );
};
