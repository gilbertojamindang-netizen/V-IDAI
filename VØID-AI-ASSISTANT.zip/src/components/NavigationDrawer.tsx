import React from 'react';
import { 
  Bot, 
  Database, 
  Sliders, 
  ShieldCheck, 
  KeyRound, 
  Monitor, 
  Smartphone, 
  Code2, 
  X, 
  ChevronRight,
  Radio,
  Wifi
} from 'lucide-react';
import { ScreenId } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface NavigationDrawerProps {
  isOpen: boolean;
  activeScreen: ScreenId;
  onSelectScreen: (screen: ScreenId) => void;
  onClose: () => void;
  isOnline?: boolean;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  activeScreen,
  onSelectScreen,
  onClose,
  isOnline = true,
}) => {
  if (!isOpen) return null;

  const handleNav = (screen: ScreenId) => {
    onSelectScreen(screen);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex animate-fadeIn">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Surface */}
      <div className="relative w-80 max-w-[85vw] h-full bg-[#050505] border-r border-white/10 shadow-2xl flex flex-col justify-between z-10">
        
        {/* Drawer Header */}
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-xl overflow-hidden border border-cyan-400/60 shadow-[0_0_15px_rgba(6,182,212,0.4)] shrink-0 bg-black">
                <img 
                  src="/logo.jpg" 
                  alt="VØID.AI Logo" 
                  className="w-full h-full object-cover" 
                />
              </div>
              <div>
                <h2 className="text-base font-bold tracking-widest text-white font-display">VØID.AI</h2>
                <div className="flex items-center gap-1.5 text-[10px] tracking-wider font-mono text-zinc-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  <span>ONLINE // STANDALONE</span>
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-colors"
              aria-label="Close navigation"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Layers (Three-Layer Structure) */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">

          {/* LAYER 1: NEURAL CORE */}
          <div>
            <div className="px-2 mb-2 flex items-center justify-between text-[10px] font-mono tracking-widest text-zinc-400 uppercase">
              <span>Layer 1: Neural Core</span>
              <span className="text-cyan-400/80">[01]</span>
            </div>
            <div className="space-y-1">
              <button
                onClick={() => handleNav('home')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'home'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Bot className={`w-4 h-4 ${activeScreen === 'home' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>Home Voice Assistant</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => handleNav('memory')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'memory'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Database className={`w-4 h-4 ${activeScreen === 'memory' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>Memory (Room DB 30MB)</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>
            </div>
          </div>

          {/* LAYER 2: CYBER-PHYSICAL & REMOTE OPS */}
          <div>
            <div className="px-2 mb-2 flex items-center justify-between text-[10px] font-mono tracking-widest text-zinc-400 uppercase">
              <span>Layer 2: Remote Ops</span>
              <span className="text-cyan-400/80">[02]</span>
            </div>
            <div className="space-y-1">
              <button
                onClick={() => handleNav('pccloud')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'pccloud'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Monitor className={`w-4 h-4 ${activeScreen === 'pccloud' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>PC Cloud Mode</span>
                </div>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  QuickTrip
                </span>
              </button>

              <button
                onClick={() => handleNav('phoneaccessibility')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'phoneaccessibility'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Smartphone className={`w-4 h-4 ${activeScreen === 'phoneaccessibility' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>Phone Control & Screen</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => handleNav('codestudio')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'codestudio'
                    ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-500 shadow-[0_0_12px_rgba(0,240,255,0.2)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Code2 className={`w-4 h-4 ${activeScreen === 'codestudio' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>AI Coding Studio</span>
                </div>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-900/40 text-cyan-200 border border-cyan-800">
                  Dev
                </span>
              </button>
            </div>
          </div>

          {/* LAYER 3: SYSTEM ARCHITECTURE & SECURITY */}
          <div>
            <div className="px-2 mb-2 flex items-center justify-between text-[10px] font-mono tracking-widest text-zinc-400 uppercase">
              <span>Layer 3: Security & Config</span>
              <span className="text-cyan-400/80">[03]</span>
            </div>
            <div className="space-y-1">
              <button
                onClick={() => handleNav('permissions')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'permissions'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <ShieldCheck className={`w-4 h-4 ${activeScreen === 'permissions' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>Permissions & Daemons</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => handleNav('apisettings')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'apisettings'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <KeyRound className={`w-4 h-4 ${activeScreen === 'apisettings' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>API Settings (Encrypted)</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => handleNav('settings')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'settings'
                    ? 'bg-white/10 text-white border border-white/20 shadow-[0_0_12px_rgba(255,255,255,0.1)]'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Sliders className={`w-4 h-4 ${activeScreen === 'settings' ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>Preferences & Tone</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => handleNav('androidsource')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  activeScreen === 'androidsource'
                    ? 'bg-cyan-950/40 text-cyan-300 border border-cyan-800 shadow-[0_0_12px_rgba(0,240,255,0.15)]'
                    : 'text-cyan-400/80 hover:text-cyan-300 hover:bg-cyan-950/20'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Code2 className="w-4 h-4 text-cyan-400" />
                  <span>Android Project Source</span>
                </div>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-900/60 text-cyan-200">
                  Compose
                </span>
              </button>
            </div>
          </div>

          {/* Standalone PWA & App Section */}
          <div className="pt-2">
            <PWAInstallButton variant="banner" />
          </div>

        </div>

        {/* Drawer Footer Status */}
        <div className="p-4 border-t border-white/10 bg-black/50">
          <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400">
            <span className="flex items-center gap-1.5">
              <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
              <span>FOREGROUND DAEMON</span>
            </span>
            <span className="text-emerald-400 font-semibold">ACTIVE</span>
          </div>
          <div className="mt-1 text-[10px] text-zinc-400 font-mono">
            Charon Live Engine • 30 MB DB Quota
          </div>
        </div>

      </div>
    </div>
  );
};
