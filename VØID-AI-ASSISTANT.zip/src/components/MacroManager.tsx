import React, { useState } from 'react';
import { 
  Workflow, 
  Plus, 
  Trash2, 
  Play, 
  Check, 
  X, 
  Smartphone, 
  Monitor, 
  Keyboard, 
  Volume2, 
  Camera, 
  ArrowDown, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  Clock,
  Layers
} from 'lucide-react';
import { VoiceMacro, MacroAction, MacroActionType } from '../types';

interface MacroManagerProps {
  macros: VoiceMacro[];
  onAddMacro: (macro: VoiceMacro) => void;
  onUpdateMacro: (macro: VoiceMacro) => void;
  onDeleteMacro: (id: string) => void;
  onExecuteMacro: (macro: VoiceMacro) => void;
  executingMacroId?: string | null;
}

export const MacroManager: React.FC<MacroManagerProps> = ({
  macros,
  onAddMacro,
  onUpdateMacro,
  onDeleteMacro,
  onExecuteMacro,
  executingMacroId,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [triggerInput, setTriggerInput] = useState('');
  const [descInput, setDescInput] = useState('');
  const [actionList, setActionList] = useState<MacroAction[]>([]);
  
  // Action Creator Draft State
  const [selectedActionType, setSelectedActionType] = useState<MacroActionType>('open_app');
  const [actionApp, setActionApp] = useState('Chrome');
  const [actionPcConnect, setActionPcConnect] = useState(true);
  const [actionPcText, setActionPcText] = useState('npm run dev');
  const [actionShortcut, setActionShortcut] = useState('Ctrl + C');
  const [actionPitch, setActionPitch] = useState(0.70);
  const [actionDirection, setActionDirection] = useState<'up' | 'down'>('down');
  const [actionSpeech, setActionSpeech] = useState('Sequence executed. System standing by.');

  const handleAddActionToDraft = () => {
    let title = '';
    let payload: any = {};

    switch (selectedActionType) {
      case 'open_app':
        title = `Launch App: ${actionApp}`;
        payload = { app: actionApp };
        break;
      case 'connect_pc':
        title = actionPcConnect ? 'Connect to PC Cloud' : 'Disconnect PC Cloud';
        payload = { connect: actionPcConnect };
        break;
      case 'pc_type':
        title = `Type on PC: "${actionPcText}"`;
        payload = { text: actionPcText };
        break;
      case 'pc_shortcut':
        title = `Execute PC Shortcut: ${actionShortcut}`;
        payload = { key: actionShortcut };
        break;
      case 'set_voice_tone':
        title = `Set Voice Pitch to ${actionPitch}x`;
        payload = { pitch: actionPitch };
        break;
      case 'take_screenshot':
        title = 'Capture Display Screenshot';
        payload = {};
        break;
      case 'scroll_screen':
        title = `Scroll Display ${actionDirection.toUpperCase()}`;
        payload = { direction: actionDirection };
        break;
      case 'speak_phrase':
        title = `Speak: "${actionSpeech}"`;
        payload = { message: actionSpeech };
        break;
    }

    const newAction: MacroAction = {
      id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: selectedActionType,
      title,
      payload
    };

    setActionList(prev => [...prev, newAction]);
  };

  const handleRemoveDraftAction = (id: string) => {
    setActionList(prev => prev.filter(a => a.id !== id));
  };

  const handleSaveMacro = (e: React.FormEvent) => {
    e.preventDefault();
    if (!triggerInput.trim()) return;
    if (actionList.length === 0) return;

    // Clean trigger phrase without "VOID" prefix for flexible matching
    const cleanTrigger = triggerInput.trim().replace(/^void,?\s*/i, '');

    const newMacro: VoiceMacro = {
      id: `macro_${Date.now()}`,
      triggerPhrase: cleanTrigger,
      description: descInput.trim() || `Automated sequence for "${cleanTrigger}"`,
      enabled: true,
      actions: actionList,
      executionCount: 0
    };

    onAddMacro(newMacro);
    setIsCreating(false);
    setTriggerInput('');
    setDescInput('');
    setActionList([]);
  };

  const getActionIcon = (type: MacroActionType) => {
    switch (type) {
      case 'open_app': return <Smartphone className="w-3.5 h-3.5 text-emerald-400" />;
      case 'connect_pc': return <Monitor className="w-3.5 h-3.5 text-cyan-400" />;
      case 'pc_type': return <Keyboard className="w-3.5 h-3.5 text-blue-400" />;
      case 'pc_shortcut': return <Keyboard className="w-3.5 h-3.5 text-indigo-400" />;
      case 'set_voice_tone': return <Volume2 className="w-3.5 h-3.5 text-amber-400" />;
      case 'take_screenshot': return <Camera className="w-3.5 h-3.5 text-purple-400" />;
      case 'scroll_screen': return <ArrowDown className="w-3.5 h-3.5 text-teal-400" />;
      case 'speak_phrase': return <Volume2 className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  return (
    <div className="bg-zinc-950 p-5 rounded-2xl border border-white/10 flex flex-col gap-4 select-none">
      
      {/* HEADER & ADD BUTTON */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2.5">
          <Workflow className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="text-sm font-bold font-mono tracking-wider text-white">
              Tactical Voice Macro Manager
            </h2>
            <p className="text-[11px] text-zinc-400 font-sans">
              Define custom voice triggers executing multi-step automation chains
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsCreating(true)}
          className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-mono font-bold flex items-center gap-1.5 transition-all active:scale-95 shadow-[0_0_12px_rgba(0,240,255,0.3)]"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>NEW MACRO</span>
        </button>
      </div>

      {/* MACRO LIST */}
      <div className="space-y-3">
        {macros.length === 0 ? (
          <div className="p-8 text-center text-zinc-500 font-mono text-xs border border-dashed border-white/10 rounded-xl">
            No voice macros configured. Click "NEW MACRO" to create a custom automated sequence.
          </div>
        ) : (
          macros.map((macro) => {
            const isRunning = executingMacroId === macro.id;
            return (
              <div
                key={macro.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  isRunning
                    ? 'bg-cyan-950/40 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.25)]'
                    : macro.enabled
                    ? 'bg-black/70 border-white/10 hover:border-white/20'
                    : 'bg-black/40 border-white/5 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-mono text-white bg-zinc-900 border border-white/15 px-2 py-0.5 rounded">
                      "VOID, {macro.triggerPhrase}"
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400">
                      • {macro.actions.length} Actions
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Execution count */}
                    {macro.executionCount > 0 && (
                      <span className="text-[9px] font-mono text-zinc-500 hidden sm:inline">
                        Triggered {macro.executionCount}x
                      </span>
                    )}

                    {/* Enable Toggle */}
                    <button
                      onClick={() => onUpdateMacro({ ...macro, enabled: !macro.enabled })}
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors ${
                        macro.enabled
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : 'bg-zinc-900 text-zinc-500 border-zinc-800'
                      }`}
                    >
                      {macro.enabled ? 'ACTIVE' : 'DISABLED'}
                    </button>

                    {/* Run Test Button */}
                    <button
                      onClick={() => onExecuteMacro(macro)}
                      disabled={isRunning}
                      className="p-1.5 rounded-lg bg-zinc-900 hover:bg-cyan-500/20 text-cyan-400 hover:text-cyan-300 border border-white/10 transition-all active:scale-95 disabled:opacity-50"
                      title="Test run macro sequence"
                    >
                      <Play className="w-3.5 h-3.5 fill-cyan-400" />
                    </button>

                    {/* Delete Button */}
                    <button
                      onClick={() => onDeleteMacro(macro.id)}
                      className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                      title="Delete macro"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <p className="text-[11px] text-zinc-300 font-sans mb-2.5">
                  {macro.description}
                </p>

                {/* Steps Visual Chain */}
                <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono">
                  {macro.actions.map((act, idx) => (
                    <React.Fragment key={act.id}>
                      <span className="px-2 py-1 rounded bg-zinc-900 border border-white/10 text-zinc-300 flex items-center gap-1.5">
                        {getActionIcon(act.type)}
                        <span className="truncate max-w-[150px]">{act.title}</span>
                      </span>
                      {idx < macro.actions.length - 1 && (
                        <span className="text-zinc-600 font-bold">→</span>
                      )}
                    </React.Fragment>
                  ))}
                </div>

                {isRunning && (
                  <div className="mt-2 text-[10px] font-mono text-cyan-400 flex items-center gap-2 animate-pulse">
                    <Sparkles className="w-3 h-3" />
                    <span>Executing macro sequence in real-time...</span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* CREATE MACRO MODAL */}
      {isCreating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-lg bg-[#08080a] border border-white/20 rounded-2xl shadow-2xl p-6 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Workflow className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold font-mono text-white tracking-wide">
                  CREATE NEW VOICE MACRO
                </h3>
              </div>
              <button
                onClick={() => setIsCreating(false)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveMacro} className="space-y-4">
              
              {/* TRIGGER PHRASE */}
              <div>
                <label className="text-[10px] font-mono uppercase text-zinc-400 block mb-1">
                  Voice Trigger Phrase (After "VOID, ...")
                </label>
                <div className="flex items-center gap-2 bg-black border border-white/20 rounded-xl px-3 py-2 text-xs font-mono">
                  <span className="text-cyan-400 font-bold">"VOID,</span>
                  <input
                    type="text"
                    value={triggerInput}
                    onChange={(e) => setTriggerInput(e.target.value)}
                    placeholder="start work / gaming mode / night lock"
                    className="flex-1 bg-transparent text-white focus:outline-none"
                    required
                  />
                  <span className="text-cyan-400 font-bold">"</span>
                </div>
              </div>

              {/* DESCRIPTION */}
              <div>
                <label className="text-[10px] font-mono uppercase text-zinc-400 block mb-1">
                  Description / Intent
                </label>
                <input
                  type="text"
                  value={descInput}
                  onChange={(e) => setDescInput(e.target.value)}
                  placeholder="e.g., Opens Chrome, links to workstation, and sets volume"
                  className="w-full bg-black border border-white/20 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none"
                />
              </div>

              {/* ACTION BUILDER BOX */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-mono text-white flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    Configure Action Steps ({actionList.length})
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500">Executes sequentially</span>
                </div>

                {/* CURRENT ACTIONS LIST IN DRAFT */}
                {actionList.length > 0 && (
                  <div className="space-y-1.5">
                    {actionList.map((act, index) => (
                      <div
                        key={act.id}
                        className="flex items-center justify-between p-2 rounded-lg bg-black border border-white/10 text-xs font-mono"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="text-cyan-400 font-bold">{index + 1}.</span>
                          {getActionIcon(act.type)}
                          <span className="text-zinc-200 truncate">{act.title}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveDraftAction(act.id)}
                          className="text-zinc-500 hover:text-rose-400 p-1"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* ADD ACTION FORM */}
                <div className="pt-2 border-t border-white/10 space-y-2">
                  <label className="text-[10px] font-mono text-zinc-400 uppercase block">
                    Add Step to Sequence:
                  </label>

                  {/* ACTION TYPE SELECTOR */}
                  <select
                    value={selectedActionType}
                    onChange={(e) => setSelectedActionType(e.target.value as MacroActionType)}
                    className="w-full bg-black border border-white/20 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="open_app">1. Open Phone App (Accessibility)</option>
                    <option value="connect_pc">2. Connect / Disconnect PC Cloud</option>
                    <option value="pc_type">3. Type Automated Text on PC</option>
                    <option value="pc_shortcut">4. Execute PC Key Shortcut</option>
                    <option value="set_voice_tone">5. Adjust VOID Voice / Volume</option>
                    <option value="take_screenshot">6. Capture Phone Screenshot</option>
                    <option value="scroll_screen">7. Scroll Display</option>
                    <option value="speak_phrase">8. Speak Custom Verbal Confirmation</option>
                  </select>

                  {/* ACTION SPECIFIC INPUTS */}
                  {selectedActionType === 'open_app' && (
                    <div className="flex gap-2">
                      <select
                        value={actionApp}
                        onChange={(e) => setActionApp(e.target.value)}
                        className="flex-1 bg-black border border-white/20 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                      >
                        <option value="Chrome">Chrome Browser</option>
                        <option value="Instagram">Instagram</option>
                        <option value="Terminal">Terminal Shell</option>
                        <option value="Messages">Messages</option>
                        <option value="Maps">Google Maps</option>
                        <option value="Camera">Camera</option>
                        <option value="QR Scanner">QR Scanner</option>
                        <option value="Settings">Settings</option>
                      </select>
                    </div>
                  )}

                  {selectedActionType === 'connect_pc' && (
                    <div className="flex gap-2 text-xs font-mono">
                      <button
                        type="button"
                        onClick={() => setActionPcConnect(true)}
                        className={`flex-1 py-1.5 rounded border ${
                          actionPcConnect ? 'bg-cyan-950 text-cyan-300 border-cyan-500' : 'bg-black border-white/10 text-zinc-400'
                        }`}
                      >
                        Connect PC Link
                      </button>
                      <button
                        type="button"
                        onClick={() => setActionPcConnect(false)}
                        className={`flex-1 py-1.5 rounded border ${
                          !actionPcConnect ? 'bg-rose-950 text-rose-300 border-rose-500' : 'bg-black border-white/10 text-zinc-400'
                        }`}
                      >
                        Disconnect Link
                      </button>
                    </div>
                  )}

                  {selectedActionType === 'pc_type' && (
                    <input
                      type="text"
                      value={actionPcText}
                      onChange={(e) => setActionPcText(e.target.value)}
                      placeholder="e.g., npm run dev, git pull origin main"
                      className="w-full bg-black border border-white/20 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none"
                    />
                  )}

                  {selectedActionType === 'pc_shortcut' && (
                    <select
                      value={actionShortcut}
                      onChange={(e) => setActionShortcut(e.target.value)}
                      className="w-full bg-black border border-white/20 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                    >
                      <option value="Ctrl + C">Ctrl + C (Cancel Process)</option>
                      <option value="Alt + Tab">Alt + Tab (Switch Window)</option>
                      <option value="Win / Super">Super / Windows Key</option>
                      <option value="Enter">Enter</option>
                      <option value="Ctrl + S">Ctrl + S (Save)</option>
                    </select>
                  )}

                  {selectedActionType === 'set_voice_tone' && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                        <span>Acoustic Pitch:</span>
                        <span className="text-cyan-400">{actionPitch}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.55"
                        max="1.0"
                        step="0.05"
                        value={actionPitch}
                        onChange={(e) => setActionPitch(parseFloat(e.target.value))}
                        className="w-full accent-cyan-400"
                      />
                    </div>
                  )}

                  {selectedActionType === 'scroll_screen' && (
                    <div className="flex gap-2 text-xs font-mono">
                      <button
                        type="button"
                        onClick={() => setActionDirection('down')}
                        className={`flex-1 py-1.5 rounded border ${actionDirection === 'down' ? 'bg-cyan-950 text-cyan-300 border-cyan-500' : 'bg-black border-white/10 text-zinc-400'}`}
                      >
                        Scroll Down
                      </button>
                      <button
                        type="button"
                        onClick={() => setActionDirection('up')}
                        className={`flex-1 py-1.5 rounded border ${actionDirection === 'up' ? 'bg-cyan-950 text-cyan-300 border-cyan-500' : 'bg-black border-white/10 text-zinc-400'}`}
                      >
                        Scroll Up
                      </button>
                    </div>
                  )}

                  {selectedActionType === 'speak_phrase' && (
                    <input
                      type="text"
                      value={actionSpeech}
                      onChange={(e) => setActionSpeech(e.target.value)}
                      placeholder="e.g., Work session active. All monitors ready."
                      className="w-full bg-black border border-white/20 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none"
                    />
                  )}

                  <button
                    type="button"
                    onClick={handleAddActionToDraft}
                    className="w-full py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-white/20 text-xs font-mono text-zinc-200 hover:text-white flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Append Action to Chain</span>
                  </button>
                </div>
              </div>

              {/* SAVE & CANCEL */}
              <div className="flex gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="flex-1 py-2 rounded-xl bg-zinc-900 border border-white/15 text-xs font-mono text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!triggerInput.trim() || actionList.length === 0}
                  className="flex-1 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-mono font-bold text-xs disabled:opacity-40 transition-all shadow-[0_0_15px_rgba(0,240,255,0.4)]"
                >
                  SAVE MACRO
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
