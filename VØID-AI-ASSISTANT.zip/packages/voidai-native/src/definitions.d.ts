import type { PluginListenerHandle } from '@capacitor/core';

export interface SpeechResult {
  success: boolean;
  text?: string;
  alternatives?: string[];
  error?: string;
}

export interface VoidaiNativePlugin {
  // Speech recognition
  startListening(): Promise<SpeechResult>;
  stopListening(): Promise<void>;

  // Text-to-speech
  speak(options: { text: string }): Promise<{ utteranceId: string }>;
  stopSpeaking(): Promise<void>;
  setVoiceParams(options: { pitch?: number; rate?: number }): Promise<void>;

  // Accessibility automation
  isAccessibilityServiceEnabled(): Promise<{ enabled: boolean }>;
  openAccessibilitySettings(): Promise<void>;
  openApp(options: { packageName: string }): Promise<{ success: boolean }>;
  readScreen(): Promise<{ items: string[] }>;
  tapByLabel(options: { label: string }): Promise<{ success: boolean }>;
  tapAt(options: { x: number; y: number }): Promise<{ success: boolean }>;
  typeText(options: { text: string }): Promise<{ success: boolean }>;
  scroll(options: { forward: boolean }): Promise<{ success: boolean }>;
  globalAction(options: { action: 'home' | 'back' | 'recents' | 'notifications' }): Promise<{ success: boolean }>;

  // Overlay permission
  hasOverlayPermission(): Promise<{ granted: boolean }>;
  requestOverlayPermission(): Promise<void>;

  // Offline local LLM (MediaPipe)
  loadLlmModel(options: { modelPath: string; maxTokens?: number }): Promise<{ success: boolean }>;
  isLlmLoaded(): Promise<{ loaded: boolean }>;
  askLlm(options: { prompt: string; usePersona?: boolean }): Promise<{ reply: string }>;
  unloadLlmModel(): Promise<void>;

  // PC Cloud control (WebSocket bridge to your companion desktop app)
  pcConnect(options: { host: string; port?: number; authToken?: string }): Promise<void>;
  pcDisconnect(): Promise<void>;
  pcIsConnected(): Promise<{ connected: boolean }>;
  pcSendMouseMove(options: { dx: number; dy: number }): Promise<{ success: boolean }>;
  pcSendMouseClick(options: { button?: 'left' | 'right' | 'middle'; action?: 'down' | 'up' | 'click' }): Promise<{ success: boolean }>;
  pcSendMouseScroll(options: { amount: number }): Promise<{ success: boolean }>;
  pcSendKeyEvent(options: { code: string; action?: 'down' | 'up' | 'press' }): Promise<{ success: boolean }>;
  pcSendText(options: { text: string }): Promise<{ success: boolean }>;
  pcSendMacro(options: { steps: any[] }): Promise<{ success: boolean }>;

  // Code generation bridge — AI-authored code written straight to device storage
  saveCodeSnippet(options: { filename: string; content: string }): Promise<{ path: string }>;
  readCodeSnippet(options: { filename: string }): Promise<{ content: string }>;
  listCodeSnippets(): Promise<{ files: string[] }>;
  deleteCodeSnippet(options: { filename: string }): Promise<{ success: boolean }>;

  // Events: 'listeningState' | 'volumeLevel' | 'listeningError' | 'partialResult' | 'speechState'
  addListener(eventName: string, listenerFunc: (data: any) => void): Promise<PluginListenerHandle>;
}
