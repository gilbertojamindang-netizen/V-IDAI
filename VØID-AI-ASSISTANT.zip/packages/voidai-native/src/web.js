import { WebPlugin } from '@capacitor/core';

/**
 * Browser fallback. None of the native offline features exist outside the
 * Android app, so these just reject clearly instead of silently no-op-ing.
 */
export class VoidaiNativeWeb extends WebPlugin {
  async startListening() { throw this.unavailable('Native speech recognition is Android-only.'); }
  async stopListening() { throw this.unavailable('Native speech recognition is Android-only.'); }
  async speak() { throw this.unavailable('Native TTS is Android-only.'); }
  async stopSpeaking() { throw this.unavailable('Native TTS is Android-only.'); }
  async setVoiceParams() { throw this.unavailable('Native TTS is Android-only.'); }
  async isAccessibilityServiceEnabled() { return { enabled: false }; }
  async openAccessibilitySettings() { throw this.unavailable('Android-only.'); }
  async openApp() { throw this.unavailable('Android-only.'); }
  async readScreen() { throw this.unavailable('Android-only.'); }
  async tapByLabel() { throw this.unavailable('Android-only.'); }
  async tapAt() { throw this.unavailable('Android-only.'); }
  async typeText() { throw this.unavailable('Android-only.'); }
  async scroll() { throw this.unavailable('Android-only.'); }
  async globalAction() { throw this.unavailable('Android-only.'); }
  async hasOverlayPermission() { return { granted: false }; }
  async requestOverlayPermission() { throw this.unavailable('Android-only.'); }
  async loadLlmModel() { throw this.unavailable('Android-only.'); }
  async isLlmLoaded() { return { loaded: false }; }
  async askLlm() { throw this.unavailable('Android-only.'); }
  async unloadLlmModel() { throw this.unavailable('Android-only.'); }
  async pcConnect() { throw this.unavailable('Android-only.'); }
  async pcDisconnect() { throw this.unavailable('Android-only.'); }
  async pcIsConnected() { return { connected: false }; }
  async pcSendMouseMove() { throw this.unavailable('Android-only.'); }
  async pcSendMouseClick() { throw this.unavailable('Android-only.'); }
  async pcSendMouseScroll() { throw this.unavailable('Android-only.'); }
  async pcSendKeyEvent() { throw this.unavailable('Android-only.'); }
  async pcSendText() { throw this.unavailable('Android-only.'); }
  async pcSendMacro() { throw this.unavailable('Android-only.'); }
  async saveCodeSnippet() { throw this.unavailable('Android-only.'); }
  async readCodeSnippet() { throw this.unavailable('Android-only.'); }
  async listCodeSnippets() { return { files: [] }; }
  async deleteCodeSnippet() { throw this.unavailable('Android-only.'); }
}
