import { registerPlugin } from '@capacitor/core';

const VoidaiNative = registerPlugin('VoidaiNative', {
  web: () => import('./web.js').then((m) => new m.VoidaiNativeWeb()),
});

export { VoidaiNative };
