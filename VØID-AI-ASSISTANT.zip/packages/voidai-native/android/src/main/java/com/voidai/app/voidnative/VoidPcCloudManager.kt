package com.voidai.app.voidnative

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Talks to a companion desktop app over a plain WebSocket on your local
 * network. VOID sends small JSON input-event messages; your PC-side
 * companion app is responsible for actually injecting them (e.g. with
 * Windows SendInput / a library like java-robot, or on Linux with
 * ydotool/xdotool). This class only handles the Android→PC transport.
 *
 * Message shapes sent to the PC:
 *   {"type":"mouse_move","dx":12,"dy":-4}
 *   {"type":"mouse_click","button":"left","action":"down"|"up"|"click"}
 *   {"type":"mouse_scroll","amount":-3}
 *   {"type":"key","code":"VK_RETURN","action":"down"|"up"|"press"}
 *   {"type":"text","value":"hello world"}
 */
class VoidPcCloudManager(
    private val onStateChange: (connected: Boolean, message: String) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS) // keep the LAN socket alive
        .build()

    private var socket: WebSocket? = null
    @Volatile var isConnected: Boolean = false
        private set

    fun connect(host: String, port: Int, authToken: String? = null) {
        disconnect()
        val url = "ws://$host:$port/void-pc-bridge"
        val builder = Request.Builder().url(url)
        if (!authToken.isNullOrEmpty()) {
            builder.addHeader("Authorization", "Bearer $authToken")
        }

        socket = client.newWebSocket(builder.build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isConnected = true
                onStateChange(true, "Connected to PC at $host:$port")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
                onStateChange(false, "Connection closing: $reason")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
                onStateChange(false, "Disconnected: $reason")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                onStateChange(false, "Connection failed: ${t.message}")
            }
        })
    }

    fun disconnect() {
        socket?.close(1000, "Client disconnect")
        socket = null
        isConnected = false
    }

    private fun send(json: JSONObject): Boolean {
        val s = socket ?: return false
        return s.send(json.toString())
    }

    fun sendMouseMove(dx: Double, dy: Double) = send(
        JSONObject().put("type", "mouse_move").put("dx", dx).put("dy", dy)
    )

    fun sendMouseClick(button: String, action: String) = send(
        JSONObject().put("type", "mouse_click").put("button", button).put("action", action)
    )

    fun sendMouseScroll(amount: Double) = send(
        JSONObject().put("type", "mouse_scroll").put("amount", amount)
    )

    fun sendKeyEvent(code: String, action: String) = send(
        JSONObject().put("type", "key").put("code", code).put("action", action)
    )

    fun sendText(value: String) = send(
        JSONObject().put("type", "text").put("value", value)
    )

    fun sendMacro(steps: org.json.JSONArray) = send(
        JSONObject().put("type", "macro").put("steps", steps)
    )
}
