package com.voidai.app.voidnative

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.TextUtils
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import java.util.Locale

@CapacitorPlugin(
    name = "VoidaiNative",
    permissions = [
        Permission(strings = [android.Manifest.permission.RECORD_AUDIO], alias = "microphone")
    ]
)
class VoidaiNativePlugin : Plugin() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var llmEngine: VoidLlmEngine? = null
    private var pcCloud: VoidPcCloudManager? = null

    private val VOID_PERSONA = "You are VOID, a calm, tactical, concise AI assistant. " +
        "Keep replies to 1-3 sentences, confident and direct. User: "

    override fun load() {
        super.load()
        initTts()
        llmEngine = VoidLlmEngine(context)
        pcCloud = VoidPcCloudManager { connected, message ->
            notifyListeners(
                "pcCloudState",
                JSObject().put("connected", connected).put("message", message)
            )
        }
    }

    // ---------------------------------------------------------------------
    // Offline speech recognition
    // ---------------------------------------------------------------------

    @PluginMethod
    fun startListening(call: PluginCall) {
        if (getPermissionState("microphone") != com.getcapacitor.PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "listeningPermissionCallback")
            return
        }
        beginListening(call)
    }

    @PermissionCallback
    private fun listeningPermissionCallback(call: PluginCall) {
        if (getPermissionState("microphone") == com.getcapacitor.PermissionState.GRANTED) {
            beginListening(call)
        } else {
            call.reject("Microphone permission denied")
        }
    }

    private fun beginListening(call: PluginCall) {
        val ctx: Context = context
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            call.reject("SpeechRecognizer not available on this device")
            return
        }

        activity.runOnUiThread {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(ctx)

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                // EXTRA_PREFER_OFFLINE asks Android to use the on-device model
                // (downloaded under Settings > System > Languages > On-device speech
                // recognition) instead of a network-backed recognizer.
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    notifyListeners("listeningState", JSObject().put("state", "ready"))
                }

                override fun onBeginningOfSpeech() {
                    notifyListeners("listeningState", JSObject().put("state", "speaking"))
                }

                override fun onRmsChanged(rmsdB: Float) {
                    notifyListeners("volumeLevel", JSObject().put("level", rmsdB))
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    notifyListeners("listeningState", JSObject().put("state", "processing"))
                }

                override fun onError(error: Int) {
                    val ret = JSObject().put("code", error).put("message", describeError(error))
                    notifyListeners("listeningError", ret)
                    if (call.isKeptAlive.not()) { /* no-op */ }
                    call.resolve(JSObject().put("success", false).put("error", describeError(error)))
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull() ?: ""
                    val arr = JSArray()
                    matches?.forEach { arr.put(it) }
                    call.resolve(JSObject().put("success", true).put("text", best).put("alternatives", arr))
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull() ?: return
                    notifyListeners("partialResult", JSObject().put("text", best))
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            speechRecognizer?.startListening(intent)
        }
    }

    @PluginMethod
    fun stopListening(call: PluginCall) {
        activity.runOnUiThread {
            speechRecognizer?.stopListening()
        }
        call.resolve()
    }

    private fun describeError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
        SpeechRecognizer.ERROR_CLIENT -> "Client side error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Missing microphone permission"
        SpeechRecognizer.ERROR_NETWORK -> "Network error"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
        SpeechRecognizer.ERROR_NO_MATCH -> "No speech match"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
        SpeechRecognizer.ERROR_SERVER -> "Server error"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input"
        else -> "Unknown error ($code)"
    }

    // ---------------------------------------------------------------------
    // Offline text-to-speech
    // ---------------------------------------------------------------------

    private fun initTts() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                applyDeepMaleVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        notifyListeners("speechState", JSObject().put("state", "started").put("id", utteranceId))
                    }
                    override fun onDone(utteranceId: String?) {
                        notifyListeners("speechState", JSObject().put("state", "done").put("id", utteranceId))
                    }
                    override fun onError(utteranceId: String?) {
                        notifyListeners("speechState", JSObject().put("state", "error").put("id", utteranceId))
                    }
                })
            }
        }
    }

    /**
     * Picks the lowest-pitched, male-leaning voice the device's TTS engine
     * offers, then lowers pitch/rate further for the Charon/Fenrir tactical
     * tone. Device voice quality varies — for a consistently deep, natural
     * voice across devices, install Google's "Wavenet"-style voice data via
     * Settings > Accessibility > Text-to-speech output > Google TTS > Install
     * voice data (still fully offline once downloaded), or swap in an
     * offline neural engine like Piper (see ANDROID_BUILD.md).
     */
    private fun applyDeepMaleVoice() {
        val engine = tts ?: return
        val candidates = engine.voices?.filter {
            it.locale.language == Locale.getDefault().language && !it.isNetworkConnectionRequired
        } ?: emptyList()

        val maleVoice = candidates.firstOrNull { v ->
            val n = v.name.lowercase()
            n.contains("male") && !n.contains("female")
        } ?: candidates.firstOrNull()

        maleVoice?.let { engine.voice = it }
        engine.setPitch(0.78f)     // lower pitch = deeper voice
        engine.setSpeechRate(0.95f) // steady, slightly measured pace
    }

    @PluginMethod
    fun speak(call: PluginCall) {
        val text = call.getString("text")
        if (TextUtils.isEmpty(text)) {
            call.reject("No text provided")
            return
        }
        if (!ttsReady) {
            call.reject("TTS engine not ready yet")
            return
        }
        val utteranceId = "voidai-${System.currentTimeMillis()}"
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        call.resolve(JSObject().put("utteranceId", utteranceId))
    }

    @PluginMethod
    fun stopSpeaking(call: PluginCall) {
        tts?.stop()
        call.resolve()
    }

    @PluginMethod
    fun setVoiceParams(call: PluginCall) {
        val pitch = call.getFloat("pitch") ?: 0.78f
        val rate = call.getFloat("rate") ?: 0.95f
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
        call.resolve()
    }

    // ---------------------------------------------------------------------
    // Accessibility bridge
    // ---------------------------------------------------------------------

    @PluginMethod
    fun isAccessibilityServiceEnabled(call: PluginCall) {
        call.resolve(JSObject().put("enabled", VoidAccessibilityService.instance != null))
    }

    @PluginMethod
    fun openAccessibilitySettings(call: PluginCall) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        call.resolve()
    }

    @PluginMethod
    fun openApp(call: PluginCall) {
        val pkg = call.getString("packageName") ?: return call.reject("packageName required")
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        call.resolve(JSObject().put("success", svc.openApp(pkg)))
    }

    @PluginMethod
    fun readScreen(call: PluginCall) {
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        call.resolve(JSObject().put("items", svc.dumpScreenText()))
    }

    @PluginMethod
    fun tapByLabel(call: PluginCall) {
        val label = call.getString("label") ?: return call.reject("label required")
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        call.resolve(JSObject().put("success", svc.findAndClick(label)))
    }

    @PluginMethod
    fun tapAt(call: PluginCall) {
        val x = call.getFloat("x") ?: return call.reject("x required")
        val y = call.getFloat("y") ?: return call.reject("y required")
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        call.resolve(JSObject().put("success", svc.tapAt(x, y)))
    }

    @PluginMethod
    fun typeText(call: PluginCall) {
        val text = call.getString("text") ?: return call.reject("text required")
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        call.resolve(JSObject().put("success", svc.typeIntoFocused(text)))
    }

    @PluginMethod
    fun scroll(call: PluginCall) {
        val forward = call.getBoolean("forward") ?: true
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        call.resolve(JSObject().put("success", svc.scroll(forward)))
    }

    @PluginMethod
    fun globalAction(call: PluginCall) {
        val action = call.getString("action") ?: return call.reject("action required")
        val svc = VoidAccessibilityService.instance
            ?: return call.reject("Accessibility service is not enabled")
        val ok = when (action) {
            "home" -> svc.goHome()
            "back" -> svc.goBack()
            "recents" -> svc.openRecents()
            "notifications" -> svc.openNotifications()
            else -> false
        }
        call.resolve(JSObject().put("success", ok))
    }

    // ---------------------------------------------------------------------
    // Offline local LLM (MediaPipe) — the "AI brain", no cloud, no API key
    // ---------------------------------------------------------------------

    @PluginMethod
    fun loadLlmModel(call: PluginCall) {
        val path = call.getString("modelPath") ?: return call.reject("modelPath required")
        val maxTokens = call.getInt("maxTokens") ?: 512
        Thread {
            try {
                val ok = llmEngine?.loadModel(path, maxTokens) ?: false
                if (ok) call.resolve(JSObject().put("success", true))
                else call.reject("Model file not found at $path")
            } catch (e: Exception) {
                call.reject("Failed to load model: ${e.message}")
            }
        }.start()
    }

    @PluginMethod
    fun isLlmLoaded(call: PluginCall) {
        call.resolve(JSObject().put("loaded", llmEngine?.isLoaded() ?: false))
    }

    @PluginMethod
    fun askLlm(call: PluginCall) {
        val prompt = call.getString("prompt") ?: return call.reject("prompt required")
        val usePersona = call.getBoolean("usePersona") ?: true
        val engine = llmEngine
        if (engine == null || !engine.isLoaded()) {
            call.reject("LLM not loaded — call loadLlmModel() first")
            return
        }
        Thread {
            try {
                val fullPrompt = if (usePersona) VOID_PERSONA + prompt else prompt
                val reply = engine.generate(fullPrompt)
                call.resolve(JSObject().put("reply", reply))
            } catch (e: Exception) {
                call.reject("Inference failed: ${e.message}")
            }
        }.start()
    }

    @PluginMethod
    fun unloadLlmModel(call: PluginCall) {
        llmEngine?.close()
        call.resolve()
    }

    // ---------------------------------------------------------------------
    // PC Cloud control — forwards input events to a companion desktop app
    // over a LAN WebSocket. This plugin only transports events; actually
    // injecting mouse/keyboard input happens in YOUR companion app on the PC.
    // ---------------------------------------------------------------------

    @PluginMethod
    fun pcConnect(call: PluginCall) {
        val host = call.getString("host") ?: return call.reject("host required")
        val port = call.getInt("port") ?: 8765
        val token = call.getString("authToken")
        pcCloud?.connect(host, port, token)
        call.resolve()
    }

    @PluginMethod
    fun pcDisconnect(call: PluginCall) {
        pcCloud?.disconnect()
        call.resolve()
    }

    @PluginMethod
    fun pcIsConnected(call: PluginCall) {
        call.resolve(JSObject().put("connected", pcCloud?.isConnected ?: false))
    }

    @PluginMethod
    fun pcSendMouseMove(call: PluginCall) {
        val dx = call.getDouble("dx") ?: return call.reject("dx required")
        val dy = call.getDouble("dy") ?: return call.reject("dy required")
        call.resolve(JSObject().put("success", pcCloud?.sendMouseMove(dx, dy) ?: false))
    }

    @PluginMethod
    fun pcSendMouseClick(call: PluginCall) {
        val button = call.getString("button") ?: "left"
        val action = call.getString("action") ?: "click"
        call.resolve(JSObject().put("success", pcCloud?.sendMouseClick(button, action) ?: false))
    }

    @PluginMethod
    fun pcSendMouseScroll(call: PluginCall) {
        val amount = call.getDouble("amount") ?: return call.reject("amount required")
        call.resolve(JSObject().put("success", pcCloud?.sendMouseScroll(amount) ?: false))
    }

    @PluginMethod
    fun pcSendKeyEvent(call: PluginCall) {
        val code = call.getString("code") ?: return call.reject("code required")
        val action = call.getString("action") ?: "press"
        call.resolve(JSObject().put("success", pcCloud?.sendKeyEvent(code, action) ?: false))
    }

    @PluginMethod
    fun pcSendText(call: PluginCall) {
        val text = call.getString("text") ?: return call.reject("text required")
        call.resolve(JSObject().put("success", pcCloud?.sendText(text) ?: false))
    }

    @PluginMethod
    fun pcSendMacro(call: PluginCall) {
        val steps = call.getArray("steps") ?: return call.reject("steps required")
        call.resolve(JSObject().put("success", pcCloud?.sendMacro(steps) ?: false))
    }

    // ---------------------------------------------------------------------
    // Code generation bridge — lets AI-authored code be written straight to
    // on-device storage (e.g. for AiCodeStudioScreenView to export/share)
    // rather than just living as a chat string.
    // ---------------------------------------------------------------------

    private fun codeDir(): java.io.File {
        val dir = java.io.File(context.filesDir, "void_code_snippets")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    @PluginMethod
    fun saveCodeSnippet(call: PluginCall) {
        val filename = call.getString("filename") ?: return call.reject("filename required")
        val content = call.getString("content") ?: return call.reject("content required")
        if (filename.contains("..") || filename.contains("/")) {
            return call.reject("Invalid filename")
        }
        try {
            val file = java.io.File(codeDir(), filename)
            file.writeText(content)
            call.resolve(JSObject().put("path", file.absolutePath))
        } catch (e: Exception) {
            call.reject("Failed to save: ${e.message}")
        }
    }

    @PluginMethod
    fun readCodeSnippet(call: PluginCall) {
        val filename = call.getString("filename") ?: return call.reject("filename required")
        try {
            val file = java.io.File(codeDir(), filename)
            if (!file.exists()) return call.reject("File not found")
            call.resolve(JSObject().put("content", file.readText()))
        } catch (e: Exception) {
            call.reject("Failed to read: ${e.message}")
        }
    }

    @PluginMethod
    fun listCodeSnippets(call: PluginCall) {
        val arr = JSArray()
        codeDir().listFiles()?.sortedByDescending { it.lastModified() }?.forEach { arr.put(it.name) }
        call.resolve(JSObject().put("files", arr))
    }

    @PluginMethod
    fun deleteCodeSnippet(call: PluginCall) {
        val filename = call.getString("filename") ?: return call.reject("filename required")
        val file = java.io.File(codeDir(), filename)
        call.resolve(JSObject().put("success", file.delete()))
    }

    // ---------------------------------------------------------------------
    // Overlay ("draw over other apps") permission
    // ---------------------------------------------------------------------

    @PluginMethod
    fun hasOverlayPermission(call: PluginCall) {
        val granted = Settings.canDrawOverlays(context)
        call.resolve(JSObject().put("granted", granted))
    }

    @PluginMethod
    fun requestOverlayPermission(call: PluginCall) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        call.resolve()
    }
}
