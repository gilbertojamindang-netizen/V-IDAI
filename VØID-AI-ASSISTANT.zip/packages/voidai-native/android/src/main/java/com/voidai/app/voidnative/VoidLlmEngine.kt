package com.voidai.app.voidnative

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import java.io.File

/**
 * Thin wrapper around MediaPipe's LLM Inference API — runs a quantized local
 * model (e.g. Gemma 2 2B, Phi-3-mini, or Llama 3.2 1B/3B converted to
 * MediaPipe's .task format) entirely on-device. No network calls, no API
 * key, no cost.
 *
 * The .task model file (1.5–4+ GB depending on the model) is NOT bundled in
 * the APK — see ANDROID_BUILD.md for where to get one and how to get it onto
 * the device. This class just loads whatever file sits at [modelPath].
 */
class VoidLlmEngine(private val context: Context) {

    private var llm: LlmInference? = null

    fun isLoaded(): Boolean = llm != null

    fun loadModel(modelPath: String, maxTokens: Int = 512): Boolean {
        if (!File(modelPath).exists()) return false
        close()
        val options = LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(maxTokens)
            .build()
        llm = LlmInference.createFromOptions(context, options)
        return true
    }

    /** Blocking single-shot generation. Call from a background thread. */
    fun generate(prompt: String): String {
        val engine = llm ?: throw IllegalStateException("Model not loaded — call loadModel() first")
        return engine.generateResponse(prompt)
    }

    fun close() {
        llm?.close()
        llm = null
    }
}
