package com.voidai.app.voidnative

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

/**
 * VOID.AI's AccessibilityService.
 *
 * Does nothing on its own. It only acts when a command comes in from
 * VoidaiNativePlugin (which the JS/React side calls explicitly, after the
 * user has asked VOID to do something). The user must manually flip this on
 * in Settings > Accessibility > VOID.AI Control — Android does not allow an
 * app to self-enable this permission.
 */
class VoidAccessibilityService : AccessibilityService() {

    companion object {
        // Lets the Capacitor plugin reach the live service instance, and lets
        // the UI check "is the service actually running right now".
        var instance: VoidAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No passive logging/collection here by design — VOID only inspects
        // the screen when explicitly asked (see dumpScreenText / findAndClick).
    }

    override fun onInterrupt() {}

    /** Opens any installed app by its package name. */
    fun openApp(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
        return true
    }

    /** Reads all visible, non-empty text on screen as a flat JSON array of strings. */
    fun dumpScreenText(): JSONArray {
        val results = JSONArray()
        val root = rootInActiveWindow ?: return results
        collectText(root, results)
        return results
    }

    private fun collectText(node: AccessibilityNodeInfo, out: JSONArray) {
        val text = node.text?.toString()
        if (!text.isNullOrBlank()) out.put(text)
        val desc = node.contentDescription?.toString()
        if (!desc.isNullOrBlank() && desc != text) out.put(desc)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, out) }
        }
    }

    /**
     * Finds the first clickable node whose text or content-description
     * contains [label] (case-insensitive) and performs a click on it.
     * Returns true if a match was found and clicked.
     */
    fun findAndClick(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val match = findNode(root, label.lowercase()) ?: return false
        return clickNodeOrParent(match)
    }

    private fun findNode(node: AccessibilityNodeInfo, needle: String): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase()
        val desc = node.contentDescription?.toString()?.lowercase()
        if ((text != null && text.contains(needle)) || (desc != null && desc.contains(needle))) {
            return node
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findNode(child, needle)?.let { return it }
            }
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        // Fall back to a raw tap gesture at the node's screen bounds.
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return tapAt(bounds.exactCenterX(), bounds.exactCenterY())
    }

    /** Dispatches a single-finger tap gesture at the given screen coordinates. */
    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /** Scrolls the first scrollable container forward (down) or backward (up). */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                     else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findScrollable(child)?.let { return it }
            }
        }
        return null
    }

    /** Types [text] into the currently focused editable field, if any. */
    fun typeIntoFocused(text: String): Boolean {
        val focused = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = android.os.Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            text
        )
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
}
