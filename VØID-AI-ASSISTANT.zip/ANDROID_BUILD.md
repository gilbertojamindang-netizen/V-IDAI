# VOID.AI — Native Android Build

This project is now configured for Capacitor. Because generating the `android/`
platform folder requires downloading Capacitor's Android template from npm
(network access), it is **not** physically included in this ZIP — it gets
generated automatically the first time the GitHub Actions workflow runs.

## What's included
- `@capacitor/core`, `@capacitor/android`, `@capacitor/cli` added to `package.json`
- `capacitor.config.ts` — appId `com.voidai.app`, appName `VOID.AI`, `webDir: dist`,
  no `server.url` set so the app loads the built `dist/` bundle locally (offline)
- `.github/workflows/android-build.yml` — CI pipeline that:
  1. `npm install`
  2. `npm run build` (Vite build → `dist/`)
  3. `npx cap add android` (generates the native project, first run only)
  4. `npx cap sync android`
  5. `./gradlew assembleDebug`
  6. Uploads `app-debug.apk` as a workflow artifact

## To build the APK
1. Push this project to a GitHub repo.
2. Go to **Actions → Build Android APK → Run workflow** (or just push to `main`).
3. Download `void-ai-debug-apk` from the completed run's artifacts.

## To generate the `android/` folder locally instead
```bash
npm install
npm run build
npx cap add android
npx cap sync android
```
After this runs once, commit the resulting `android/` folder if you want it
version-controlled (the workflow will detect it and skip re-adding it).

## Note on the Gemini API
`server.ts` currently proxies Gemini calls through an Express backend. A
native app has no Node server bundled with it — if you need live AI replies
on-device, you'll want to call the Gemini API directly from the client (using
`customApiKey` from API Settings) or point the app at a deployed instance of
`server.ts`. Right now, offline the app will fall back to the local responses
already built into `server.ts`'s fallback logic.

---

# Offline native features (voidai-native plugin)

Everything below lives in `packages/voidai-native/` — a local Capacitor
plugin. `npx cap sync android` auto-discovers it (it's a normal npm
dependency with a `capacitor` field in its `package.json`), merges its
`AndroidManifest.xml` into your app's manifest, and registers the plugin —
no manual MainActivity edits needed.

## 1. Offline voice recognition
`VoidaiNative.startListening()` uses Android's built-in `SpeechRecognizer`
with `EXTRA_PREFER_OFFLINE = true`. For it to actually run offline, the
on-device speech model must be downloaded once per device at:
**Settings → System → Languages & input → On-device speech recognition**
(or on some OEMs: **Settings → Google → Voice → Offline speech recognition**).
Without that, Android transparently falls back to its network recognizer.

```ts
const { text } = await VoidaiNative.startListening();
```

## 2. Offline TTS with a deep male voice
`VoidaiNative.speak({ text })` uses Android's on-device `TextToSpeech`
engine, auto-picks a male-leaning offline voice, and lowers pitch/rate for
the tactical tone. Voice quality depends on what's installed on the device —
for a noticeably better voice:
**Settings → Accessibility → Text-to-speech output → (gear icon next to the
engine) → Install voice data**. This is a one-time download; playback itself
is fully offline afterward.

If you want a materially deeper/more consistent voice than any stock
Android TTS engine offers, the next step up (still free, still offline) is
bundling a neural TTS engine like **Piper** (ONNX-based, runs on-device) and
swapping it in behind the same `speak()` call — that's a larger addition, ask
if you want that wired in too.

## 3. Offline local LLM (the "AI brain")
`VoidaiNative.askLlm({ prompt })` runs inference via MediaPipe's
`LlmInference` task — fully on-device, no network, no API key.

**You still need to get a `.task` model file onto the device** — it's too
large to ship inside the APK/repo:

1. Pick a small quantized model already converted to MediaPipe's format —
   e.g. Gemma 2 2B or Gemma 3 1B (int4), or Phi-3-mini-int4, published on
   Hugging Face / Kaggle Models under the MediaPipe / LiteRT community orgs.
2. Download it once, either:
   - **At first app launch**: have the app download it to
     `context.filesDir` from a URL you host (your own storage — large
     download, so warn the user and only do this on Wi-Fi), or
   - **For development**: push it manually —
     `adb push gemma-2b-it-int4.task /data/local/tmp/` then move/copy it into
     the app's files dir, or use `adb push` directly into
     `/data/data/com.voidai.app/files/` on a debug build.
3. Load it once per session:
   ```ts
   await VoidaiNative.loadLlmModel({ modelPath: '/data/user/0/com.voidai.app/files/model.task' });
   const { reply } = await VoidaiNative.askLlm({ prompt: 'Status report.' });
   ```

Expect 1.5–4 GB depending on the model, and inference is CPU/GPU-bound on
the phone — a 1–2B parameter model is realistic on modern mid-range+
hardware; don't expect desktop-LLM speed.

## 4. Accessibility Service (phone control)
`VoidAccessibilityService.kt` can read on-screen text, tap by label or
coordinates, type into the focused field, scroll, launch apps, and trigger
global actions (home/back/recents/notifications). None of it runs until the
user explicitly enables it:

```ts
const { enabled } = await VoidaiNative.isAccessibilityServiceEnabled();
if (!enabled) {
  await VoidaiNative.openAccessibilitySettings(); // opens system Settings
  // user manually toggles "VOID.AI Control" on — Android requires this,
  // no app can self-grant this permission
}
```

Then:
```ts
await VoidaiNative.openApp({ packageName: 'com.instagram.android' });
await VoidaiNative.tapByLabel({ label: 'Send' });
const { items } = await VoidaiNative.readScreen();
```

## 5. Permissions summary

| Permission | How it's requested |
|---|---|
| Microphone (`RECORD_AUDIO`) | Auto-requested the first time you call `startListening()` — standard Android runtime permission dialog, handled by the plugin's `@CapacitorPlugin(permissions = ...)` annotation. |
| Overlay (`SYSTEM_ALERT_WINDOW`) | Not a runtime dialog — must send the user to Settings: `await VoidaiNative.requestOverlayPermission()`. Check first with `hasOverlayPermission()`. |
| Accessibility Service | Not a runtime dialog either — `await VoidaiNative.openAccessibilitySettings()`, then the user flips it on manually. Poll `isAccessibilityServiceEnabled()` (e.g. on app resume) to detect when they've done it. |
| Notifications (`POST_NOTIFICATIONS`, Android 13+) | Declared in the plugin manifest; request it the same way you'd request any other Capacitor runtime permission if you add a foreground "always listening" service later. |

All permissions are declared once in `packages/voidai-native/android/src/main/AndroidManifest.xml` and merge into your app automatically — you don't need to touch the generated `android/app/src/main/AndroidManifest.xml` by hand.

## 6. PC Cloud control
`VoidPcCloudManager.kt` is a WebSocket **client** — it only sends small JSON
input-event messages over your local network. It does not inject anything
itself. You need a companion app running on the PC that:

1. Opens a WebSocket server, e.g. on `ws://<pc-lan-ip>:8765/void-pc-bridge`
2. Receives JSON messages like:
   ```json
   {"type":"mouse_move","dx":12,"dy":-4}
   {"type":"mouse_click","button":"left","action":"click"}
   {"type":"mouse_scroll","amount":-3}
   {"type":"key","code":"VK_RETURN","action":"press"}
   {"type":"text","value":"hello world"}
   ```
3. Actually moves the mouse / types, using something like Java's `Robot`
   class, Python's `pyautogui`, or a native Win32 `SendInput` wrapper.

Phone side:
```ts
await VoidaiNative.pcConnect({ host: '192.168.1.42', port: 8765 });
await VoidaiNative.pcSendMouseMove({ dx: 10, dy: 0 });
await VoidaiNative.pcSendMouseClick({ button: 'left', action: 'click' });
await VoidaiNative.pcSendText({ text: 'Hello from VOID' });
```

Both devices must be on the same network (or reachable via VPN/Tailscale) —
there's no cloud relay, by design, so nothing leaves your LAN. This also
means `usesCleartextTraffic="true"` is set for the app (plain `ws://`, no
TLS) since the companion app is addressed by a bare LAN IP; swap to `wss://`
with a cert if you ever expose this beyond your own network.

I didn't write the PC-side companion app here — that's a separate desktop
project (Electron/C#/Python, your call) that just needs to speak this same
JSON protocol on the same route. Happy to write that too if you tell me
what stack you want it in.

## 7. Code generation bridge
`saveCodeSnippet` / `readCodeSnippet` / `listCodeSnippets` write AI-authored
code straight to the app's private storage (`filesDir/void_code_snippets/`),
so `AiCodeStudioScreenView` can persist, list, and reopen generated files
instead of just holding them as a chat string:

```ts
const { path } = await VoidaiNative.saveCodeSnippet({
  filename: 'macro.py',
  content: generatedCode,
});
const { files } = await VoidaiNative.listCodeSnippets();
const { content } = await VoidaiNative.readCodeSnippet({ filename: 'macro.py' });
```

To let the user actually export/share a saved file (not just keep it in app
storage), pair this with `@capacitor/share` or `@capacitor/filesystem`'s
share intent — ask if you want that wired in too.

